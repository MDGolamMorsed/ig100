--[[
Nybsys Configuration Libarary 

Description:
Utilites for interact with nybsys ig100 cofiguration 

CREATE AT: 29 April 2019
CREATED BY: Kousher Alam <kousheralampranto@gmail.com>
Copyright @ Nybsys <https://nybsys.com>

]]--

local io     = require "io"
local os     = require "os"
local table  = require "table"
local nixio  = require "nixio"
local fs     = require "nixio.fs"
local uci    = require "luci.model.uci"

local luci  = {}
luci.util   = require "luci.util"
luci.ip     = require "luci.ip"
luci.json  = require 'luci.json'
luci.sys  = require 'luci.sys'

local tonumber, ipairs, pairs, pcall, type, next, setmetatable, require, select =
	tonumber, ipairs, pairs, pcall, type, next, setmetatable, require, select


-- save all configuration of ig100 gateway 
local config_file = "/usr/lib/lua/luci/config/config.json"

-- save all sensor configuration files 
local sensor_file = "/usr/lib/lua/luci/config/sensor.json"

-- save all user defined custom sensor configuration 
local custom_sensor = "/usr/lib/lua/luci/config/custom_sensor.json"

-- log file open
local log_file = "/usr/lib/lua/luci/log/syslog.json"

 


--- Export Module as luci.nybsys module  
module "luci.nybsys"



--- export some global configuration 
function appConstant()
    return {
        sensor_config_url = "admin/config/sconfig2",
        output_config_url = "admin/config/output_config",
		host_name_url = "admin/system/hostname",
		datetime_url = "admin/system/datetime",
		wan_url = "admin/network/wan",
    }
end


--- helper function for read a file and returns it content 
function fs_get(file_to_read, tmp_name, isJson)
    local config_tmp = "/tmp/"
    if tmp_name ~= nil then 
        config_tmp = config_tmp .. tmp_name
    else 
        config_tmp = config_tmp .. "nyb_sys_config_0"
    end 

    local file = io.open(file_to_read, "rb")
    if file then
        os.execute("cat ".. file_to_read .." > ".. config_tmp)
        file:close()
    end

    local result_data = {}
    local tmp_file = io.open(config_tmp, "rb")
    if tmp_file then
        result_data = tmp_file:read("*a")
        tmp_file:close()
    end

    if isJson == false then 
        return result_data
    else
        return luci.json.decode(result_data)
    end
end

-- A generel utitlity function for updating data on disk 
function fs_put(file_name, data)
    local writer = io.open(file_name, 'w')
    if writer ~= nil and writer then 
        writer:write(luci.json.encode(data))
        writer:close()
    else
        return false 
    end
end


--- update config file
function fs_saveConfig(data)
    return fs_put(config_file, data)
end

-- update sensor file 
function fs_saveSensor(data)
    return fs_put(sensor_file, data)
end

--- update custom sensor file
function fs_saveConfigCustom(data)
    return fs_put(custom_sensor, data)
end


--- A Utility function for get file content of config.json file 
function fs_getConfig()
    return fs_get(config_file, "configdata", true)
end 


function fs_getCustomConfig()
    return fs_get(custom_sensor, "configCustomdata")
end 

function fs_getlog()
    return fs_get(log_file, "logdata", true)
end 

 
 
function getSensorstatusDigital(configs)
    if configs ~= nil then 
        return configs.statusDigital
    else 
        return {}
    end 
end

function getSensorstatusAnalog(configs)
    if configs ~= nil then 
        return configs.statusAnalog
    else 
        return {}
    end 
end
 
function fs_getHostName(configs)
    if configs ~= nil then 
        return configs.host
    else 
        return {}
    end 
end



function getInputs(configs)
    if configs ~= nil then 
        return configs.inputs
    else 
        return {}
    end 
end

function getTriggers(config)
    if configs ~= nil then 
        return configs.triggers
    else 
        return {}
    end
end


function getOutputs(configs)
    if configs ~= nil then 
        return configs.outputs
    else 
        return {}
    end
end 


function getConfiguredOutputs(configs)
    if configs ~= nil then 
        return configs.output_config
    else 
        return {}
    end
end 

--- A Utility function for get file content of sensor.json file 
function fs_getSensorConfig()
    return fs_get(sensor_file, "sensordata")
end 


--- A Utility function for get file content of custom_sensor.json file 
function fs_getCustomSensor()
    return fs_get(custom_sensor, "sensordata")
end 


function stringToArray(line)
  if line ~= nil then 
  --return line:gmatch("%S+")
     for w in line:gmatch("%S+") do return  w end
  end
end 



function setDigitalInput(mac, pin) 
    if pin < 10 then 
        pin = "0" .. pin 
    else 
        pin = tostring(pin)
    end
    local payload = '{ "message_uid": "0001", "payload": { "command": "CONFIGURE_DIGTIAL_PIN","pin": '.. pin ..', "value": 1}}'
    -- os.execute("mosquitto_pub -t '/ig100/".. mac .."/request' -m '".. payload .."'")
end 

function resetDigitalInput(mac, pin) 
    if pin < 10 then 
        pin = "0" .. pin 
    else 
        pin = tostring(pin)
    end
    local payload = '{ "message_uid": "0001", "payload": { "command": "CONFIGURE_DIGTIAL_PIN","pin": '.. pin ..', "value": 0}}'
    -- os.execute("mosquitto_pub -t '/ig100/".. mac .."/request' -m '".. payload .."'")
end 

function setInterrupt(mac, pin) 
    local payload = '{ "message_uid": "0001", "payload": { "command": "CONFIGURE_INTERRUPT_PIN","pin": "'.. pin ..'", "value": 1}}'
    -- os.execute("mosquitto_pub -t '/ig100/".. mac .."/request' -m '".. payload .."'")
end 

function resetInterrupt(mac, pin) 
    local payload = '{ "message_uid": "0001", "payload": { "command": "CONFIGURE_INTERRUPT_PIN","pin": "'.. pin ..'", "value": 0}}'
    -- os.execute("mosquitto_pub -t '/ig100/".. mac .."/request' -m '".. payload .."'")
end 

function setAnalogInput(mac, pin) 
    local payload = '{ "message_uid": "0001", "payload": { "command": "CONFIGURE_ANALOG_PIN","pin": "'.. pin ..'", "value": 1}}'
    -- os.execute("mosquitto_pub -t '/ig100/".. mac .."/request' -m '".. payload .."'")
end 

function resetAnalogInput(mac, pin) 
    local payload = '{ "message_uid": "0001", "payload": { "command": "CONFIGURE_ANALOG_PIN","pin": "'.. pin ..'", "value": 0}}'
    -- os.execute("mosquitto_pub -t '/ig100/".. mac .."/request' -m '".. payload .."'")
end 

function setPwmOutput(mac, pin) 
    local payload = '{ "message_uid": "0001", "payload": { "command": "CONFIGURE_PWM_PIN","pin": "'.. pin ..'", "value": 1}}'
    -- os.execute("mosquitto_pub -t '/ig100/".. mac .."/request' -m '".. payload .."'")
end 

function resetPwmOutput(mac, pin) 
    local payload = '{ "message_uid": "0001", "payload": { "command": "CONFIGURE_PWM_PIN","pin": "'.. pin ..'", "value": 0}}'
    -- os.execute("mosquitto_pub -t '/ig100/".. mac .."/request' -m '".. payload .."'")
end 

function setRelayOutput(mac, pin) 
    local payload = '{ "message_uid": "0001", "payload": { "command": "CONFIGURE_RELAY_PIN","pin": "'.. pin ..'", "value": 1}}'
    -- os.execute("mosquitto_pub -t '/ig100/".. mac .."/request' -m '".. payload .."'")
end 

function resetRelayOutput(mac, pin) 
    local payload = '{ "message_uid": "0001", "payload": { "command": "CONFIGURE_RELAY_PIN","pin": "'.. pin ..'", "value": 0}}'
    -- os.execute("mosquitto_pub -t '/ig100/".. mac .."/request' -m '".. payload .."'")
end 


