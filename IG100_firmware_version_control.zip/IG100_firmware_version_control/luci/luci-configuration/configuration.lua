module("luci.controller.configuration.configuration", package.seeall)

function index()
     entry({"admin", "new_tab"}, firstchild(), "New tab", 60).dependent=false
     --this adds the first sub-tab that is located in 
     -- <luci-path>/luci-myapplication/model/cbi/myapp-mymodule and the file is called cbi_tab.lua, 
     -- also set to first position
     entry({"admin", "new_tab", "tab_from_cbi"}, cbi("cbi_tab"), "CBI Tab", 1) 
     
     --this adds the second sub-tab that is located in 
     -- <luci-path>/luci-myapplication/view/myapp-mymodule and the file is called view_tab.htm, 
     -- also set to the second position
     entry({"admin", "new_tab", "tab_from_view"}, template("view_tab"), "View Tab", 2)  
end
