require "nixio"
module("luci.controller.ig100.device", package.seeall)
local nybsys = require "luci.nybsys"

function index()
	entry({"device"}, alias("device", "info"))
    entry({"device", "reboot"}, call("device_reboot"), "Add New Config", 10).dependent=false
    entry({"device", "shutdown"}, call("device_shutdown"), "Get Existing Config", 10).dependent=false
    entry({"device", "info"}, call("device_info"), "Get Existing Config", 10).dependent=false
end

function session_retrieve(sid, allowed_users)
	local util = require "luci.util"
	local sdat = util.ubus("session", "get", {
		ubus_rpc_session = sid
	})
 	if type(sdat) == "table" and
	   type(sdat.values) == "table" and
	   type(sdat.values.token) == "string" and
	   type(sdat.values.user) == "string" 
	   --and util.contains(allowed_users, sdat.values.user)
	then
 		return sid, sdat.values
	end

	return nil
end

function device_reboot()
    luci.http.prepare_content("application/json")
    luci.http.header("Access-Control-Allow-Origin", "*")
    luci.http.header("Access-Control-Allow-Methods", "POST")
	local auth = luci.http.formvalue("token") 
	if auth then -- if authentication token was given 
		local sid, sdat = session_retrieve(auth) 
		if sdat then -- if given token is valid
 			luci.sys.reboot ();
			luci.http.write('{"success": true, "message": "Device rebooting"}')
		else
			luci.http.status(400, "Unathorized")
			luci.http.write_json({message="unauthorized from get", token=auth})
		end 
	else 
		luci.http.write_json({message="unauthorized from get", token="pleae provide token"})
	end
    
end

function device_shutdown()
    luci.http.prepare_content("application/json")
    luci.http.header("Access-Control-Allow-Origin", "*")
    luci.http.header("Access-Control-Allow-Methods", "POST")
	local auth = luci.http.formvalue("token") 
	if auth then -- if authentication token was given 
		local sid, sdat = session_retrieve(auth) 
		if sdat then -- if given token is valid
 			luci.sys.exec("poweroff")
			luci.http.write('{"success": true, "message": "Device shutdown"}')
		else
			luci.http.status(400, "Unathorized To shutdown")
		end 
	else 
		luci.http.write_json({message="unauthorized from get", token="pleae provide token"})
	end 
end


function device_info()
    luci.http.prepare_content("application/json")
    luci.http.header("Access-Control-Allow-Origin", "*")
	luci.http.header("Access-Control-Allow-Methods", "POST")

	local config = nybsys.fs_getConfig()
	local response = {
		name = config.name, 
		mac = config.mac, 
		isIg100 = true,
	}
	luci.http.write_json(response)
	luci.http.close()
end
