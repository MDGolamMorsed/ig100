require "nixio"
module("luci.controller.ig100.index", package.seeall)
local nybsys = require "luci.nybsys"


function index()
	-- entry({"config"}, alias("config", "get")).sysauth = "root"
	entry({"config", "add"}, call("action_config_add"), "Add New Config", 10).dependent=false
    entry({"config", "get"}, call("action_config_get"), "Get Existing Config", 10).dependent=false
    entry({"config", "getfull"}, call("config_get_full"), "Get Existing Config", 10).dependent=false
	-- entry({"sensor"}, alias("sensor", "get")).sysauth = "root"
    entry({"sensor", "add"}, call("action_sensor_add"), "Add New Config", 10).dependent=false
    entry({"sensor", "get"}, call("action_sensor_get"), "Get Existing Config", 10).dependent=false
    entry({"sensor", "custom"}, call("action_sensor_custom"), "Get Existing Config", 10).dependent=false
end


function session_retrieve(sid, allowed_users)
	local util = require "luci.util"
	local sdat = util.ubus("session", "get", {
		ubus_rpc_session = sid
	})
 	if type(sdat) == "table" and
	   type(sdat.values) == "table" and
	   type(sdat.values.token) == "string" and
	   type(sdat.values.user) == "string" 
	   --and util.contains(allowed_users, sdat.values.user)
	then
 		return sid, sdat.values
	end

	return nil
end

function config_get_full()
	luci.http.prepare_content("application/json")
	luci.http.header("Access-Control-Allow-Origin", "*")
	luci.http.header("Access-Control-Allow-Methods", "GET, POST")
	response = {
		config = nybsys.fs_getConfig(),
		sensor = nybsys.fs_getSensorConfig(),
	}
	luci.http.write_json(response)
	luci.http.close()
end

function action_config_add() 
	luci.http.prepare_content("application/json")
	luci.http.header("Access-Control-Allow-Origin", "*")
	luci.http.header("Access-Control-Allow-Methods", "GET, POST")
	-- luci.http.header("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With")
	local config = luci.http.formvalue('config')
	if config == nil then 
		luci.http.write("{message='You send nil value, please send valid data.'}")
		luci.http.close()
	else
		saveConfig = nybsys.fs_saveConfig(luci.json.decode(config))
		luci.http.write("{message='config saved'}")
		luci.http.close()
	end 
end

function file_exists(file)
    local f = io.open(file, "rb")
    if f then f:close() end
    return f ~= nil
end

function lines_from(file)
    if not file_exists(file) then return {} end
    lines = {}
    for line in io.lines(file) do 
      lines[#lines + 1] = line
    end
    return lines
end

function get_file_content(file)
    local response = "";
    local lines = lines_from(file)
    for k,v in pairs(lines) do
        response = response .. v
    end
    return response
end


function action_config_get()
    luci.http.prepare_content("application/json")
	luci.http.header("Access-Control-Allow-Origin", "*")
	luci.http.header("Access-Control-Allow-Methods", "POST")
	-- luci.http.header("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With")
	--local auth = luci.http.formvalue("token") 
	 --if auth then -- if authentication token was given 
		 --local sid, sdat = session_retrieve(auth) 
		 --if sdat then -- if given token is valid
 		 --	luci.http.write(get_file_content("config.json"))
		 --	luci.http.close()
		 --else
		 --	luci.http.status(400, "Unathorized")
		 --	luci.http.write_json({message="unauthorized from get", token=auth})
		 --end 
	 --else 
		--luci.http.write_json({message="unauthorized from get", token="pleae provide token"})
	 --end
	luci.http.write_json(nybsys.fs_getConfig())
    luci.http.close()
end


function action_sensor_add() 
    luci.http.prepare_content("application/json")
    luci.http.header("Access-Control-Allow-Origin", "*")
    local sensor = luci.http.formvalue('sensor')
	local auth = luci.http.formvalue("token") 
	if auth then -- if authentication token was given 
		local sid, sdat = session_retrieve(auth) 
				if sdat then -- if given token is valid
					 if sensor == nil then 
				luci.http.write('{"success": false, "message": "failed"}')
			else 
				file = io.open("sensor.json", "w")
				file:write(sensor)
				file:close()
				luci.http.write('{"success": true, "message": "ok"}')
			end
		else
			luci.http.status(400, "Unathorized")
			luci.http.write_json({message="unauthorized from get", token=auth})
		end 
	else 
		luci.http.write_json({message="unauthorized from get", token="pleae provide token"})
	end 
    luci.http.close()
end



function action_sensor_get()
    luci.http.prepare_content("application/json")
    luci.http.header("Access-Control-Allow-Origin", "*")
	luci.http.header("Access-Control-Allow-Methods", "POST")
	-- luci.http.header("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With")
	luci.http.write(get_file_content("sensor.json"))
	luci.http.close()

	-- local auth = luci.http.formvalue("token") 
	-- if auth then -- if authentication token was given 
	-- 	local sid, sdat = session_retrieve(auth) 
	-- 	if sdat then -- if given token is valid
 	-- 		luci.http.write(get_file_content("sensor.json"))
	-- 		luci.http.close()
	-- 	else
	-- 		luci.http.status(400, "Unathorized")
	-- 		luci.http.write_json({message="unauthorized from get", token=auth})
	-- 	end 
	-- else 
	-- 	luci.http.write_json({message="unauthorized from get", token="pleae provide token"})
	-- end
	 
    -- luci.http.close()
end


function action_sensor_custom()
    luci.http.prepare_content("application/json")
    luci.http.header("Access-Control-Allow-Origin", "*")
    local custom_sensor = luci.http.formvalue('custom_sensor') 
	local auth = luci.http.formvalue("token") 
	if auth then -- if authentication token was given 
		local sid, sdat = session_retrieve(auth) 
			 if sdat then -- if given token is valid
			 if custom_sensor == nil then 
				luci.http.write('{"success": false, "message": "failed"}')
			else 
				file = io.open("custom_sensor.json", "w")
				file:write(custom_sensor)
				file:close()
				luci.http.write('{"success": true, "message": "ok"}')
			end
		else
			luci.http.status(400, "Unathorized")
			luci.http.write_json({message="unauthorized from get", token=auth})
		end 
	else 
		luci.http.write_json({message="unauthorized from get", token="pleae provide token"})
	end
    luci.http.close()
end
