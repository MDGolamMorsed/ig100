module("luci.sauth", package.seeall)
local sys = require "luci.sys"
local util = require "luci.util"
local nixio = require("nixio")
local nybsys = require("luci.nybsys")
require "luci.config"
require "nixio"



-- require "commotion_helpers"
module("luci.controller.ig100.user", package.seeall)

function index()
    entry({"user", "login"}, call("login_user"), "Login using username and password").dependent=false
    entry({"user", "logincheck"}, call("logincheck"), "Login using username and password").dependent=false
    entry({"user", "logout"}, call("logout_user"), "logout").dependent=false
    entry({"user", "change", "name"}, call("change_username"), "Change username").dependent=false
    entry({"user", "change", "password"}, call("change_password"), "Change password").dependent=false
end
 

function session_retrieve(sid)
	local sdat = util.ubus("session", "get", {
		ubus_rpc_session = sid
	})
	local loginid = util.ubus("session", "get", {
		ubus_rpc_session = 'login'
	})
	luci.http.write_json(sdat) 
	luci.http.write_json(loginid)
 	if type(sdat) == "table" and
	   type(sdat.values) == "table" and
	   type(sdat.values.token) == "string" and
	   type(sdat.values.user) == "string" 
	then
 		return sid, sdat.values
	end
	return nil
end


function logincheck()
	luci.config.sauth = luci.config.sauth or {}
	sessionpath = luci.config.sauth.sessionpath
	sessiontime = tonumber(luci.config.sauth.sessiontime) or 15 * 60
	local token = luci.http.formvalue("token") or http.getcookie("sysauth")
	
	luci.http.write_json(token)
	if token then -- if authentication token was given 
		local s, sdat = util.ubus("session", "get")
		luci.http.write_json(s)
		luci.http.write_json(sdat)
		
		local s, sdat = util.ubus("session", "login")
		luci.http.write_json(s)
		luci.http.write_json(sdat)
	else 
		luci.http.write_json({message="unauthorized from get", token="pleae provide token"})
	end 
end



--[[
	* Login user with username and password 
--]]
function login_user() 
    luci.http.prepare_content("application/json")
    luci.http.header("Access-Control-Allow-Origin", "*")
    luci.http.header("Access-Control-Allow-Methods", "POST")
    local username = luci.http.formvalue('username')
	local password = luci.http.formvalue('password')

	local response = {
		success = true, 
		message = "successfully logged in", 
		username= username, 
	}

    if username and password then 
		local is_authenticated = luci.sys.user.checkpasswd(username, password)
		local token = nil
		
		local login = util.ubus("session", "login", {
			username = username,
			password = password,
			timeout  = tonumber(luci.config.sauth.sessiontime)
		})

		
		if type(login) == "table" then 
			token = login['ubus_rpc_session']
		else 
			response.message = "Unauthorized not logged in"
			luci.http.status(400, response.message)
			luci.http.close()
		end

		if is_authenticated then 
			response['token'] = token
			response['config'] = nybsys.fs_getConfig()
			response['sensor'] = nybsys.fs_getSensorConfig()
			luci.http.header('Set-Cookie', 'token; '..token) 
			luci.http.write_json(response)
			luci.http.close()
		else
			response.message = "Failed to login please check yoour credential"
			luci.http.status(400, response.message)
			luci.http.close()
		end
		 
	else 
		response.message = "Please enter username and password!"
		luci.http.status(400, response.message)
		luci.http.close() 
    end 
end 



function logout_user()
    luci.http.prepare_content("application/json")
    luci.http.header("Access-Control-Allow-Origin", "*")
    luci.http.header("Access-Control-Allow-Methods", "POST")
	local response = {
		success = true, 
		message = "Logout Route Work"
	}
	local auth = luci.http.formvalue("token") 
	if auth then -- if authentication token was given 
		local sid, sdat = session_retrieve(auth) 
		if sdat then -- if given token is valid
 			luci.http.write_json(response)
		else
			luci.http.status(400, "Unathorized")
		end 
	else 
		luci.http.status(400, "Please provide your token to logout")
	end     
end




-- Change username 
function change_username()
    luci.http.prepare_content("application/json")
    luci.http.header("Access-Control-Allow-Origin", "*")
	luci.http.header("Access-Control-Allow-Methods", "POST")
	
	local response = {
		success = true, 
		message = "Successflly changed your username"
	}

	local auth = luci.http.formvalue("token") 
	local username = luci.http.formvalue("username")
	if username == nil or auth == nil then 
		luci.http.status(400, "Unathorized Can no Change User name, please provide your token and user name")
		luci.http.close()
	end 
	if auth then -- if authentication token was given 
		local sid, sdat = session_retrieve(auth) 
		if sdat then -- if given token is valid

 			luci.http.write_json(response)
		else
			luci.http.status(400, "Unathorized")
		end 
	else 
		luci.http.status(400, "Unathorized, please provide your token and user name")
	end 
end

function change_password()
    luci.http.prepare_content("application/json")
    luci.http.header("Access-Control-Allow-Origin", "*")
	luci.http.header("Access-Control-Allow-Methods", "POST")
	local response = {
		success = true, 
		message = "change password Route Work"
	}

	local auth = luci.http.formvalue("token") or http.getcookie("sysauth") 
	local username = luci.http.formvalue("username")
	local password = luci.http.formvalue("password")
	local con_password = luci.http.formvalue("con_password")
	
	if auth == nil or password == nil or username == nil then 
		luci.http.status(400, "Unathorized, please provide token, username, and password")
	end 

	if not(password == con_password) then 
		luci.http.status(400, "password and confirm password does not match")
	end

	if auth then -- if authentication token was given 
		local sid, sdat = session_retrieve(auth) 
		if sdat then -- if given token is valid
			if sys.user.setpasswd(username, password) then
				luci.http.write(response)
			else 
				luci.http.status(400, "Username is not valid!")
			end 
 			
		else
			luci.http.status(400, "Unathorized, Token is not valid!!!")
		end 
	else 
		luci.http.status(400, "Unathorized, please provide token and password")
	end  
end 


