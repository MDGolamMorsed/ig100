--[[
LuCI - Lua Configuration Interface

Copyright 2008 Steven Barth <steven@midlink.org>
Copyright 2008-2011 Jo-Philipp Wich <xm@subsignal.org>
Copyright 2014 Edwin Chen <edwin@dragino.com>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

$Id$
]] --
local nixio = require "nixio"
local fs = require 'nixio.fs'
local io = require 'io'
local json = require 'luci.json'
local nybsys = require 'luci.nybsys'


module('luci.controller.admin.sensor', package.seeall)

function index()
    local uci = luci.model.uci.cursor()
    local string = string
    entry({'admin', 'sensor'}, alias('admin', 'sensor', 'mqtt'), _('Sensor'), 30).index = true

    --entry({"admin", "sensor", "service"}, cbi("admin_sensor/service"), _("IoT Service"), 1)
    entry({'admin', 'sensor', 'iotserver'}, cbi('admin_sensor/iotserver'), _('IOT Server'), 3)
    entry({'admin', 'sensor', 'mqtt'}, cbi('admin_sensor/mqtt'), _('MQTT Settings'), 20)
    entry({'admin', 'sensor', 'channel'}, cbi('admin_sensor/sub/channel'), nil).leaf = true
    entry({'admin', 'sensor', 'poweruart'}, cbi('admin_sensor/poweruart'), _('PowerUART'), 5)
    entry({'admin', 'sensor', 'mcu'}, cbi('admin_sensor/mcu'), _('MicroController'), 8)
    entry({'admin', 'sensor', 'flashmcu'}, call('upload_sketch'), _('Flash MCU'), 10)
    entry({'admin', 'sensor', 'lorawan'}, cbi('admin_sensor/lorawan'), _('LoRa / LoraWAN'), 15)
    entry({'admin', 'sensor', 'tcp_client'}, cbi('admin_sensor/tcp_client'), _('TCP Client'), 16)
    entry({'admin', 'sensor', 'sdata'}, template('admin_status/sdata'), _('Sensor Data'), 2).leaf = true
    entry({'admin', 'sensor', 'sdata_action'}, post('sdata_action')).leaf = true
	entry({'admin', 'sensor', 'authenticator'}, post('authenticator')).leaf = true
	
    -- entry({'admin', 'system', 'datetime'}, template('nysys_custom/datetime'), _('Date Time'), 2).leaf = true
    -- entry({'admin', 'system', 'hostname'}, template('nysys_custom/hostname'), _('Host Name'), 2).leaf = true
	entry({'admin', 'system', 'update_hostName_config'}, post('update_hostName_config')).leaf = true
	entry({'admin', 'system', 'update_datetime_config'}, post('update_datetime_config')).leaf = true
	entry({'admin', 'network', 'update_wan_config'}, post('update_wan_config')).leaf = true

    -- Sensor Configuration  
    -- entry({'admin', 'sensor', 'sconfig'}, template('nysys_custom/sconfig'), _('S Configuration'), 1).leaf = true
    -- entry({'admin', 'sensor', 'sconfig2'}, template('nysys_custom/sensor_config'), _('Sensor Configuration'), 1).leaf = true
    entry({'admin', 'sensor', 'save_sensor_config'}, post('save_sensor_config')).leaf = true
	entry({'admin', 'sensor', 'save_sansore_output_configs'}, post('save_sansore_output_configs')).leaf = true
    entry({'admin', 'sensor', 'update_sensor_config'}, post('update_sensor')).leaf = true
    entry({'admin', 'sensor', 'delete_sensor'}, post('delete_a_sensor')).leaf = true
	entry({'admin', 'sensor', 'delete_output'}, post('delete_output')).leaf = true
    
    -- Input Configuration 
    -- entry({'admin', 'sensor', 'input_config'}, template('nysys_custom/input_coinfig'), _('Input Configuration'), 1).leaf = true
    

    -- Output Configuration 
    -- entry({'admin', 'sensor', 'output_config'}, template('nysys_custom/output_config'), _('Output Configuration'), 1).leaf = true
    entry({'admin', 'sensor', 'save_output_config'}, post('save_output_config')).leaf = true
    entry({'admin', 'sensor', 'update_output_config'}, post('update_output_config')).leaf = true
    entry({'admin', 'sensor', 'delete_output_config'}, post('delete_output_config')).leaf = true
	entry({'admin', 'sensor', 'reboot_device'}, post('reboot_device')).leaf = true
	
	-- Diagonosis command_execution
		entry({'admin', 'diagnosis', 'command_execution'}, post('command_execution')).leaf = true

    entry({'admin', 'sensor', 'sensor_switch'}, post('on_off_sensor')).leaf = true

    --entry({"admin", "sensor", "rfgateway"}, cbi("admin_sensor/rfgateway"), _("RF Radio Gateway"), 4)

    uci:foreach(
        'iot-services',
        'server',
        function(section)
            if section['display'] == '1' then
                entry(
                    {'admin', 'sensor', 'service', section['.name']},
                    cbi('admin_sensor/' .. section['.name']),
                    _(string.upper(section['.name'])),
                    2
                )
            end
        end
    )
end

local function rfind(s, c)
    local last = 1
    while string.find(s, c, last, true) do
        last = string.find(s, c, last, true) + 1
    end
    return last
end

function upload_sketch()
    local sketch_hex = '/tmp/sketch.hex'
    local chunk_number = 0

    local fp
    luci.http.setfilehandler(
        function(meta, chunk, eof)
            if not fp then
                fp = io.open(sketch_hex, 'w')
            end
            if chunk then
                chunk_number = chunk_number + 1
                fp:write(chunk)
            end
            if eof then
                chunk_number = chunk_number + 1
                fp:close()
            end
        end
    )

    local sketch = luci.http.formvalue('sketch_hex')
    if sketch and #sketch > 0 and rfind(sketch, '.hex') > 1 then
        local merge_output = luci.util.exec('merge-sketch-with-bootloader.lua ' .. sketch_hex .. ' 2>&1')
        local kill_bridge_output = luci.util.exec('kill-bridge 2>&1')
        local run_avrdude_output = luci.util.exec("run-avrdude /tmp/sketch.hex '-q -q' 2>&1")

        local ctx = {
            merge_output = merge_output,
            kill_bridge_output = kill_bridge_output,
            run_avrdude_output = run_avrdude_output
        }
        luci.template.render('dragino/upload', ctx)
    else
        luci.template.render('dragino/flashmcu')
    end
end

function sdata_action()
    luci.http.redirect(luci.dispatcher.build_url('admin/sensor/sdata'))
end

function serializeTable(val, name, skipnewlines, depth)
    skipnewlines = skipnewlines or false
    depth = depth or 0

    local tmp = string.rep(' ', depth)

    if name then
        tmp = tmp .. name .. ' = '
    end

    if type(val) == 'table' then
        tmp = tmp .. '{' .. (not skipnewlines and '\n' or '')

        for k, v in pairs(val) do
            tmp = tmp .. serializeTable(v, k, skipnewlines, depth + 1) .. ',' .. (not skipnewlines and '\n' or '')
        end

        tmp = tmp .. string.rep(' ', depth) .. '}'
    elseif type(val) == 'number' then
        tmp = tmp .. tostring(val)
    elseif type(val) == 'string' then
        tmp = tmp .. string.format('%q', val)
    elseif type(val) == 'boolean' then
        tmp = tmp .. (val and 'true' or 'false')
    else
        tmp = tmp .. '"[inserializeable datatype:' .. type(val) .. ']"'
    end

    return tmp
end

function save_sensor_config()
    luci.http.prepare_content('application/json')

    local response = {
        messages = {},
        errors = 0
    }
	
    
	
	if luci.http.formvalue('name') == nil then
		 luci.http.write_json({message= "Definition Not Empty"}) 
	elseif luci.http.formvalue('input') == nil then
 		 luci.http.write_json({message= "Input Not Empty"}) 
	elseif luci.http.formvalue('sensor') == nil then
		luci.http.write_json({message= "Sensor Not Empty"}) 
	elseif luci.http.formvalue('note') == nil then
		 luci.http.write_json({message= "Note Not Empty"}) 
    else 
	
	local name = luci.http.formvalue('name')
	local input = luci.http.formvalue('input')
    local _uid = luci.http.formvalue('sensor')
	local note = luci.http.formvalue('note')  
	-- luci.http.write_json({message= "Input Note Not Empty"})
    local config = nybsys.fs_getConfig()
    local allSensors = nybsys.fs_getSensorConfig()
    

    if config then
        local count = nybsys.countSensors(config)
        count = count + 1

        local sensor_uid = os.time() .. count
        local _sensor = allSensors[_uid]
        if _sensor == nil then 
            _sensor = {}
        end
		 --luci.http.write_json(config[1].inputs[input])
        config[1].inputs[input]['data'] = {
            defination = name,
            sensor = _sensor.name,
            sensor_uid =  _uid,
            note = note,
        } 
		 
         nybsys.fs_saveConfig(config)
         luci.http.redirect(luci.dispatcher.build_url(nybsys.appConstant().sensor_config_url))
      end
	end
    luci.http.close()
end


function save_sansore_output_configs()

 luci.http.prepare_content('application/json')

    local response = {
        messages = {},
        errors = 0
    }
    
    local name = luci.http.formvalue('name')
    local output = luci.http.formvalue('output')
    local note = luci.http.formvalue('note')
	
    local config = nybsys.fs_getConfig()
    local allSensors = nybsys.fs_getSensorConfig()

 
	 --luci.http.write_json(config[1].outputs[output]['data'])
		  
         config[1].outputs[output]['data'] = {
              defination = name,
              note = note,
        }
		
		-- luci.sys.exec('mosquitto_pub -t "/ig100/a840411bf027/pin_config" -m  "{type: "CONFIGURE_ANALOG_PIN", pin: 0 - 3, status: 0/1}"')
		 
         nybsys.fs_saveConfig(config)
        luci.http.redirect(luci.dispatcher.build_url(nybsys.appConstant().sensor_config_url))
 
    luci.http.close()

end

function delete_output()
    luci.http.prepare_content('application/json')
    local uid = luci.http.formvalue('output-uid')

    -- read config file
    local config = nybsys.fs_getConfig()

    if uid and uid ~= "" then 
        if config and config[1].outputs[uid] then
		 --luci.http.write_json(config[1].inputs[uid].data)
		 config[1].outputs[uid].data = {}; 
           -- config[1].inputs = table.removeKey(config[1].inputs, uid);
           nybsys.fs_saveConfig(config)
            luci.http.redirect(luci.dispatcher.build_url(nybsys.appConstant().sensor_config_url))
        else
            luci.http.write_json({message= "Not found any sensor!"})
        end 
    else 
        luci.http.write_json({message= "No UID Provided"})
    end
    luci.http.close()
end

function update_sensor()
    luci.http.prepare_content('application/json')


    local name = luci.http.formvalue('name')
    local input = luci.http.formvalue('input')
    local output = luci.http.formvalue('output')
    local sensor = luci.http.formvalue('sensor')
    local note = luci.http.formvalue('note')
    local uid = luci.http.formvalue('sensor_uid')
    
    
    local config = nybsys.fs_getConfig()
    local allSensors = nybsys.fs_getSensorConfig()
    sensor = allSensors[sensor]

    if uid and uid ~= "" then 
        if config[1].sensors[uid] then
            if name ~= nil then 
                config[1].sensors[uid].name = name
                config[1].sensors[uid]['output'] = output
            end 
            if sensor ~= nil then 
                config[1].sensors[uid].sensor = sensor.name
                config[1].sensors[uid].sensor_uid = sensor.uid
                config[1].sensors[uid].sensor_type = sensor.type
            end 
            if note ~= nil then 
                config[1].sensors[uid].note = note
            end 
            if input ~= nil then
                config[1].sensors[uid].input = input 
            end 
        end
        nybsys.fs_saveConfig(config)
        luci.http.redirect(luci.dispatcher.build_url(nybsys.appConstant().sensor_config_url))
    else 
        luci.http.write_json({message= "No UID Provided"})
        luci.http.close()
    end
end




function table.removeKey(t, k_to_remove)
    local new = {}
    for k, v in pairs(t) do
      new[k] = v
    end
    new[k_to_remove] = nil
    return new
end


function delete_a_sensor()
    luci.http.prepare_content('application/json')
    local uid = luci.http.formvalue('inputs-uid')

    -- read config file
    local config = nybsys.fs_getConfig()

    if uid and uid ~= "" then 
        if config and config[1].inputs[uid] then
		 --luci.http.write_json(config[1].inputs[uid].data)
		 config[1].inputs[uid].data = {}; 
           -- config[1].inputs = table.removeKey(config[1].inputs, uid);
           nybsys.fs_saveConfig(config)
            luci.http.redirect(luci.dispatcher.build_url(nybsys.appConstant().sensor_config_url))
        else
            luci.http.write_json({message= "Not found any sensor!"})
        end 
    else 
        luci.http.write_json({message= "No UID Provided"})
    end
    luci.http.close()
end




function on_off_sensor()
    local config_file = '/www/config.json'
    luci.http.prepare_content('application/json')
    local uid = luci.http.formvalue('sensor_uid')
    local on_off = luci.http.formvalue('on_off_value')

    -- read config file
    local file = io.open(config_file, 'rb')
    if file then
        os.execute('cat ' .. config_file .. ' > /tmp/configsaveeditdata')
        file:close()
    end

    local config = nil
    
    file = io.open('/tmp/configsaveeditdata', 'rb')
    if file then
        config = file:read('*a')
        config = json.decode(config)
        file:close()
    end

    if uid and uid ~= "" then 
        if config and config[1].sensors[uid] then
            if on_off then 
                local output = config[1].sensors[uid].output
                if config[1].outputs[output] then 
                    if on_off == "" or on_off == "off" then 
                        config[1].outputs[output].isOn = true
                    else
                        config[1].outputs[output].isOn = false
                    end
                    local write_config = io.open(config_file, 'w')
                    write_config:write(json.encode(config))
                    write_config:close()
                    luci.http.redirect(luci.dispatcher.build_url('admin/sensor/sconfig'))
                else 
                    luci.http.write_json({output = output, message = "No output found"})
                end 
            else
                luci.http.write_json({message = "Please provide sensor switch value"})
            end
        else
            luci.http.write_json({message= "No sensor found!"})
        end 
    else 
        luci.http.write_json({message= "No UID Provided"})
    end
    luci.http.close()
end

function all_trim(s)
   return s:match( "^%s*(.-)%s*$" )
end

function save_output_config()

    luci.http.prepare_content('application/json')

    local response = {
            messages = {},
            errors = 0
        }
        
    local sensor_uid = luci.http.formvalue('sensor_uid')
    local name = luci.http.formvalue('name')
    local inputpin = luci.http.formvalue('inputpin')
	local conditionOparator = luci.http.formvalue('condition')
	local conditionDataValue = luci.http.formvalue('data')
    local condition = luci.http.formvalue('all_config')
    local output = all_trim(luci.http.formvalue('output-port'))
    local onoff = luci.http.formvalue('output-op')

    local config = nybsys.fs_getConfig();
	
	--local allConditions = json.decode(condition)
	--local oparator = {}
	--local dataValue = {}
	local addNewArray = {}
	local index = 0;
	
 	--for key,value in pairs(allConditions.conditions) do --actualcode 
   		--  oparator[key] = value[2]
		--  dataValue[key] = value[3]
 	--end
	
	--local joint = allConditions.joining 	 
	--local arrayOutputValue = {oparator,dataValue,joint,onoff,name}
	local arrayOutputValue = {conditionOparator,conditionDataValue,onoff,name}
    local new_output = {
	     sensor_uid = inputpin,
         conditions = {
			 values = {arrayOutputValue}
		 },
         isOn = false, 
    }
 
    if output == nil then 
        output = "relay1"
    end 

    if onoff == nil then 
        onoff = "off"
    end

    if onoff == "on" then 
        new_output.isOn = true
    else 
        new_output.isOn = false
    end
    --if config[1]['outputs']  ~= nil  then 
       -- config[1]['outputs'][output] = new_output
        if config[1]['outputs'][output] ~= ""  then  
		
 			    config[1]['outputs'][output].conditions.values[#config[1]['outputs'][output].conditions.values+1]  = arrayOutputValue 
          else 
		   config[1]['outputs'][output] = new_output 
			--luci.http.write_json({outputs = config[1]['outputs'], current_output = config[1]['outputs'][output]})
          end  

    nybsys.fs_saveConfig(config)
    luci.http.redirect(luci.dispatcher.build_url(nybsys.appConstant().output_config_url))
    luci.http.close()
end


function update_output_config()

end
function delete_output_config()
luci.http.prepare_content('application/json')
    local output_key = luci.http.formvalue('output_key')

    -- read config file
    local config = nybsys.fs_getConfig()

    if output_key and output_key ~= "" then 
        if config and config[1].outputs[output_key] then
            config[1].outputs[output_key] = ''; 
            nybsys.fs_saveConfig(config)
            luci.http.redirect(luci.dispatcher.build_url(nybsys.appConstant().output_config_url))
        else
            luci.http.write_json({message= "Not found any sensor!"})
        end 
    else 
        luci.http.write_json({message= "No UID Provided"})
    end
    luci.http.close()
end

function update_hostName_config()

	local host_name = luci.http.formvalue('host-name')
	local new_output = {
        value = host_name
    }
	local config = nybsys.fs_getConfig()

	config[1]['host']['name'] = new_output
	
	luci.sys.exec('uci set system.@system[0].hostname=' .. "'" .. host_name .. "'")

	nybsys.fs_saveConfig(config)
    luci.http.redirect(luci.dispatcher.build_url(nybsys.appConstant().host_name_url))
    luci.http.close()
end

function update_datetime_config()

	local ftime_zone = luci.http.formvalue('time-zone')
	local fyear = luci.http.formvalue('year')
	local fmonth = luci.http.formvalue('month')
	local fday = luci.http.formvalue('day')
	local fhour = luci.http.formvalue('hour')
	local fminute = luci.http.formvalue('minute')
	local fsecound = luci.http.formvalue('secound')
	local fntpserver1 = luci.http.formvalue('ntpserver1')
	local fntpserver2 = luci.http.formvalue('ntpserver2')
	
	local new_output = {
	   timezone = ftime_zone,
        date = {
			day = fday,
			year = fyear,
			month = fmonth
		},
		server = {
		    ntpserver1 = fntpserver1,
		    ntpserver2 = fntpserver2
		},
		time = {
		    hour = fhour,
			minute = fminute,
			secound = fsecound
		} 
    }
	  local config = nybsys.fs_getConfig()

	  config[1]['dateTime'] = new_output 

 	   nybsys.fs_saveConfig(config)
	     
 	  -- uci set system.ntp.server='0.lede.pool.ntp.org' '1.lede.pool.ntp.org' '2.lede.pool.ntp.org' '3.lede.pool.ntp.org'
	  
	   luci.sys.exec('uci set system.ntp.server=' .. "'" .. fntpserver1 .. "' " .. "'" .. fntpserver2 .. "'")
	   luci.sys.exec('uci set system.@system[0].timezone=' .. "'" .. ftime_zone .. "'")
	   luci.sys.exec('date -s ' .. "'" .. fyear .. "-" .. fmonth .. "-" .. fday .. " " .. fhour .. ":" .. fminute .. ":" .. fsecound .. "'" ); 
 	-- os.execute('date -s "2015-03-30  11:56:00"'); 
	
     luci.http.redirect(luci.dispatcher.build_url(nybsys.appConstant().datetime_url))
     luci.http.close()
end

function reboot_device() 
	local actionFrom = luci.http.formvalue('actionFrom')
	if (actionFrom == 'sensorePage') then 
		luci.http.redirect(luci.dispatcher.build_url(nybsys.appConstant().sensor_config_url))
	  else
	    luci.http.redirect(luci.dispatcher.build_url(nybsys.appConstant().output_config_url))
	end
	--luci.sys.reboot()
    luci.http.close()
end

function update_wan_config()

	local fconnectionType = luci.http.formvalue('connectionType')
	local fipAddress = luci.http.formvalue('ipAddress')
	local fsubnetMask = luci.http.formvalue('subnetMask')
	local fgateway = luci.http.formvalue('gateway')
	local fprimaryDnsServer = luci.http.formvalue('primaryDnsServer')
	local fsecondaryDnsServer = luci.http.formvalue('secondaryDnsServer')
	local fusername = luci.http.formvalue('username')
	local fpassword = luci.http.formvalue('password')
	local fconfirmUsername = luci.http.formvalue('confirmUsername')
	
	local new_output = {
	   connectionType = fconnectionType,
       ipAddress = fipAddress,
	   subnetMask = fsubnetMask,
	   gateway = fgateway,
	   primaryDnsServer = fprimaryDnsServer,
	   secondaryDnsServer = fsecondaryDnsServer,
	   username = fusername,
	   password = fpassword,
	   confirmUsername = fconfirmUsername,
    }
	local config = nybsys.fs_getConfig()

	config[1]['wanInterface']['config'] = new_output
	
	luci.sys.exec('uci set network.lan.ipaddr=' .. "'" .. fipAddress .. "'")
	luci.sys.exec('uci set network.lan.gateway=' .. "'" .. fgateway .. "'")
	luci.sys.exec('uci set network.lan.dns=' .. "'" .. fprimaryDnsServer .. "'")
	luci.sys.exec('uci set network.lan.type=' .. "'" .. fconnectionType .. "'")
	luci.sys.exec('uci set network.lan.netmask=' .. "'" .. fsubnetMask .. "'")
	
	--uci commit network
    --reboot

 	nybsys.fs_saveConfig(config)
    luci.http.redirect(luci.dispatcher.build_url(nybsys.appConstant().wan_url))
    luci.http.close()
end


function command_execution()

		local commandText = luci.http.formvalue('message')
		local resutlCommand = luci.sys.exec(commandText); 
		luci.http.write_json(resutlCommand)
		
		-- return resutlCommand;
		--luci.http.write_json({message= resutlCommand})
end
