--[[
LuCI - Lua Configuration Interface

Copyright 2008 Steven Barth <steven@midlink.org>
Copyright 2008-2011 Jo-Philipp Wich <xm@subsignal.org>
Copyright 2013 Edwin Chen <edwin@dragino.com>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

$Id$
]]--

module("luci.controller.admin.network", package.seeall)

function index()
	local utility = require("dragino.utility")
	local has_siod=string.find(utility.getVersion(),"SIOD")
	entry({"admin", "network"}, alias("admin", "network","network"), "Network", 40).index = true
	if has_siod == nil then
		entry({"admin", "network","network"}, cbi("secn/network"), "Internet Access", 10)
		entry({"admin", "network","lan"}, cbi("secn/lan"), "LAN and DHCP", 11)
		entry({"admin", "network","ap"}, cbi("secn/ap"), "Access Point", 30)
		entry({"admin", "network","mesh"}, cbi("secn/mesh"), "Mesh Network", 40)
	   -- entry({'admin', 'network', 'wan'}, template('nysys_custom/wan'), _('WAN Interface'), 2).leaf = true 
 	else
		entry({"admin", "network","network"}, cbi("siod/network"), "Network", 10)
	end
end

function save_wan_info()
	luci.http.prepare_content('application/json')

    local response = {
        messages = {},
        errors = 0
    }
    
    local name = luci.http.formvalue('name')
    local input = luci.http.formvalue('input')
    local _uid = luci.http.formvalue('sensor')
    local note = luci.http.formvalue('note')

    local config = nybsys.fs_getConfig()
    local allSensors = nybsys.fs_getSensorConfig()
    
    if config then
        local count = nybsys.countSensors(config)
        count = count + 1

        local sensor_uid = os.time() .. count
        local _sensor = allSensors[_uid]
        if _sensor == nil then 
            _sensor = {}
        end
        config[1].sensors[sensor_uid] = {
            name = name,
            sensor = _sensor.name,
            sensor_uid =  _uid,
            sensor_type = _sensor.type,
            note = note,
            input = input
        }

        if input and input ~= "" then
            config[1].inputs[input].isUsed = true
        end

        config[1]['total_sensor'] = count
        nybsys.fs_saveConfig(config)
        luci.http.redirect(luci.dispatcher.build_url(nybsys.appConstant().sensor_config_url))
    end
    luci.http.close()
end
