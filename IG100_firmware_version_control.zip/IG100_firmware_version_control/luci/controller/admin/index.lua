-- Copyright 2008 Steven Barth <steven@midlink.org>
-- Licensed to the public under the Apache License 2.0.

module("luci.controller.admin.index", package.seeall)
local nybsys = require 'luci.nybsys'
local json = require "luci.json"

function index()
	local root = node()
	if not root.target then
		root.target = alias("admin")
		root.index = true
	end

	local page   = node("admin")
	page.target  = firstchild()
	page.title   = _("Administration")
	page.order   = 10
	page.sysauth = "root"
	page.sysauth_authenticator = "htmlauth"
	page.ucidata = true
	page.index = true

	-- Empty services menu to be populated by addons
	entry({"admin", "services"}, firstchild(), _("Services"), 40).index = true

	entry({"admin", "config"}, template('nysys_custom/sensor_config'), _("Configuration"), 88)
	entry({'admin', 'config', 'io'}, template('nysys_custom/sensor_config'), _('I/O Configuration'), 1).leaf = true
	entry({'admin', 'config', 'trigger'}, template('nysys_custom/trigger'), _('Trigger Settings'), 2).leaf = true
	entry({'admin', 'config', 'notification'}, template('nysys_custom/notification'), _('Notification'), 3).leaf = true
	entry({'admin', 'config', 'ig100'}, template('nysys_custom/ig100'), _('IG100 Configuration'), 4).leaf = true
	entry({'admin', 'config', 'importexport'}, template('nysys_custom/importexport'), _('Import / Export'), 50).leaf = true
	entry({'admin', 'config', 'importconfig'}, call('importconfig')).leaf = false
	entry({'admin', 'config', 'save_name'}, call('save_name')).leaf = false
	entry({'admin', 'config', 'pause'}, call('pauseconfig')).leaf = false
	

	entry({'admin', 'config', 'savenotification'}, call('savenotification')).leaf = false
	entry({'admin', 'config', 'deletenotfication'}, call('deletenotfication')).leaf = false
	entry({'admin', 'config', 'input'}, call('input_config')).leaf = false
	entry({'admin', 'config', 'output'}, call('output_config')).leaf = false
	entry({'admin', 'config', 'addtrigger'}, call('addtrigger')).leaf = false
	entry({'admin', 'config', 'removetrigger'}, call('removetrigger')).leaf = false
	
	entry({"admin", "diagnosis"}, template('nysys_custom/command'), _("Diagnosis"), 89)
	entry({'admin', 'diagnosis', 'command'}, template('nysys_custom/command'), _('Command Execution'), 1).leaf = true
	entry({'admin', 'diagnosis', 'command_result'}, call('command_result')).leaf = false
	entry({'admin', 'diagnosis', 'troubleshoot'}, template('nysys_custom/troubleshoot'), _('Troubleshoot'), 1).leaf = true
	entry({'admin', 'diagnosis', 'devicelog'}, template('nysys_custom/logwindow'), _('Device Log'), 1).leaf = true

	entry({"admin", "logout"}, call("action_logout"), _("Logout"), 90)
end



function command_result()
	luci.http.prepare_content('application/json')
	local command = luci.http.formvalue('command')
	local data = luci.sys.exec('python /root/IG100_Console/ig100_cmd_parse.py ' .. command)

	luci.http.write_json({command = command, result = data})
end 



function pauseconfig()
	luci.http.prepare_content('application/json')
	local uid = luci.http.formvalue('uid')
	local pauseorresume = luci.http.formvalue('pauseorresume')

	local config = nybsys.fs_getConfig()

	if uid ~= nil then 
		if pauseorresume == 'pause' then 
			config['triggers'][uid]['isPause'] = true
		else 
			config['triggers'][uid]['isPause'] = false
		end 
	end 

	nybsys.fs_saveConfig(config)
	luci.http.redirect(luci.dispatcher.build_url("admin/config/trigger"))
end 


function save_name()
	luci.http.prepare_content('application/json')
	local name = luci.http.formvalue('ig100_name')
	local config = nybsys.fs_getConfig()

	if name ~= nil then 
		config['name']  = name
	else 
		config['name'] = "Default Name"
	end 


	nybsys.fs_saveConfig(config)
	luci.http.redirect(luci.dispatcher.build_url("admin/config/ig100"))
end


function deletenotfication()
	luci.http.prepare_content('application/json')
	local uid = luci.http.formvalue('delete_id')
	local config = nybsys.fs_getConfig()


	if config['notifications'] then 
		if config['notifications'][uid] then 
			config['notifications'][uid] = nil 
		end 
	end 

	nybsys.fs_saveConfig(config)
	luci.http.redirect(luci.dispatcher.build_url("admin/config/notification"))
end


function savenotification()
	luci.http.prepare_content('application/json')
	local name = luci.http.formvalue('not_name')
	local interval = luci.http.formvalue("not_interval")
	local updated = luci.http.formvalue("updated")
	local uid = luci.http.formvalue("notification_uid")
	local n_type = luci.http.formvalue('n_type')
	local sms_no = luci.http.formvalue('sms_no')
	local sms_text = luci.http.formvalue('sms_text')
	local eamil_no = luci.http.formvalue('eamil_no')
	local email_text = luci.http.formvalue('email_text')
	local mqtt_host = luci.http.formvalue('mqtt_host')
	local mqtt_port = luci.http.formvalue('mqtt_port')
	local mqtt_user = luci.http.formvalue('mqtt_user')
	local mqtt_pass = luci.http.formvalue('mqtt_pass')
	local mqtt_topics = luci.http.formvalue('mqtt_topics')
	local mqtt_message = luci.http.formvalue('mqtt_message')

	if uid == "" or uid == nil then 
		uid = os.time()
	end


	local nofitication = {
		name = name, 
		type = n_type,
		interval = interval,
		text =  '', 
		updated = updated, 
	}

	if n_type == 'sms' then 
		nofitication['sms_no'] = sms_no
		nofitication['text'] = sms_text
	elseif n_type == 'mail' then 
        nofitication['email'] = eamil_no
		nofitication['text'] = email_text
	else 
        nofitication['broker_host'] = mqtt_host
        nofitication['broker_port'] = mqtt_port
        nofitication['broker_username'] = mqtt_user
        nofitication['broker_password'] = mqtt_pass
        nofitication['broker_topics'] = mqtt_topics
		nofitication['text'] = mqtt_message
	end 
	
	local config = nybsys.fs_getConfig()

	if config['notifications'] then 
		config['notifications'][uid] = nofitication
	else 
		config['notifications'] = {}
		config['notifications'][uid] = nofitication
	end 

	nybsys.fs_saveConfig(config)
	luci.http.redirect(luci.dispatcher.build_url("admin/config/notification"))
end


function importconfig()
	luci.http.prepare_content('application/json')

	local mac = luci.http.formvalue('import_mac')
	local name = luci.http.formvalue('import_name')
	local inputs = luci.http.formvalue('import_inputs')
	local outputs = luci.http.formvalue('import_outputs')
	local notifications = luci.http.formvalue('import_not')
	local triggers = luci.http.formvalue('import_triggers')

	local config = nybsys.fs_getConfig()
	
	config.mac = mac
	config.name = name
	config.inputs = json.decode(inputs)
	config.outputs = json.decode(outputs)
	config.notifications = json.decode(notifications)
	config.triggers = json.decode(triggers)

	nybsys.fs_saveConfig(config)
	luci.http.redirect(luci.dispatcher.build_url("admin/config/importexport"))
	luci.http.close()
end


function addtrigger( )
	luci.http.prepare_content('application/json')
	local name = luci.http.formvalue('trigger-name')
	local descripition = luci.http.formvalue('trigger-description')
	local time = luci.http.formvalue('trigger-time')
	local condition = luci.http.formvalue('conditions')
	local uid = luci.http.formvalue('trigger_uid')
	
	if uid == "" or uid == nil then 
		uid = os.time()
	end
	
	local config = nybsys.fs_getConfig()

	time = tonumber(time)
	condition = json.decode(condition)

	-- luci.http.write(condition['outputs'])
	-- luci.http.close()

	config.triggers[uid] = {
		triggertime = 2, 
		definition= descripition, 
		trigger_name = name, 
		join_by = {},
		inputs = {}, 
		condition_value = {}, 
		condition = {}, 
		outputs = {}
	}

	if time ~= nil then 
		config.triggers[uid].triggertime = time
	end
	

	if condition['join_by'] then 
		config.triggers[uid]['join_by'] = condition['join_by'] 
	end
	if condition['inputs'] then 
		config.triggers[uid]['inputs'] = condition['inputs'] 
	end
	if condition['condition_value'] then 
		config.triggers[uid]['condition_value'] = condition['condition_value'] 
	end
	if condition['condition'] then 
		config.triggers[uid]['condition'] = condition['condition'] 
	end
	if condition['outputs'] then 
		config.triggers[uid]['outputs'] = condition['outputs'] 
	end 

	nybsys.fs_saveConfig(config)
	luci.http.redirect(luci.dispatcher.build_url("admin/config/trigger"))
	luci.http.close()
end

function removetrigger( )
	luci.http.prepare_content('application/json')
	local uid = luci.http.formvalue('uid')
	local config = nybsys.fs_getConfig()

	if(config.triggers[uid]) then 
		config.triggers[uid] = nil 
	end

	nybsys.fs_saveConfig(config)
	luci.http.redirect(luci.dispatcher.build_url("admin/config/trigger"))
	luci.http.close()
end



function input_config(  )
	luci.http.prepare_content('application/json')
    
	local inturrupt = luci.http.formvalue('interrupt')
	local updated = luci.http.formvalue("updated")
	local sensor = luci.http.formvalue('sensor')
	local name = luci.http.formvalue('definition')
	local type = luci.http.formvalue('type')
	local index = luci.http.formvalue('index')
	local uid = luci.http.formvalue('uid')
	local saveType = luci.http.formvalue('savetype')
	local resetBtn = luci.http.formvalue('resetBtn')
	
	
	
	index = tonumber(index)

	local config = nybsys.fs_getConfig()
	local mac = config.mac
 
	if resetBtn == '1' then 
	    if type == 'digital' then 
				config.inputs.digitals[index]['updated'] = updated
				config.inputs.digitals[index].isConfigured = false 
				config.inputs.digitals[index].setAsInterrupt = false 
				config.inputs.digitals[index].configuration = nil
			else 
				config.inputs.analog[index]['updated'] = updated
				config.inputs.analog[index].isConfigured = false 
				config.inputs.analog[index].configuration = nil
				-- nybsys.resetAnalogInput(mac, pin);
		 end 
	else 
		if type == 'digital' then 
			config.inputs.digitals[index].isConfigured = true 
			if inturrupt then 
				config.inputs.digitals[index].setAsInterrupt = true
				-- nybsys.setInterrupt(mac, pin)
			else 
				config.inputs.digitals[index].setAsInterrupt = false 
				-- nybsys.setDigitalInput(mac, pin)
			end 
			config.inputs.digitals[index]['updated'] = updated
			config.inputs.digitals[index].configuration = {
				defination = name,
				sensor_uid = sensor,
			}
		else 
			config.inputs.analog[index]['updated'] = updated
			config.inputs.analog[index].isConfigured = true 
			-- nybsys.setAnalogInput(mac, pin)
			config.inputs.analog[index].configuration = {
				defination = name,
				sensor_uid = sensor,
			}
		end  
 	end
	
	
	nybsys.fs_saveConfig(config)
	luci.http.redirect(luci.dispatcher.build_url("admin/config/io"))
	luci.http.close()
end

function output_config()
	luci.http.prepare_content('application/json')
    
	local name = luci.http.formvalue('definition')
	local updated = luci.http.formvalue("updated")
	local type = luci.http.formvalue('type')
	local index = luci.http.formvalue('index')
	local uid = luci.http.formvalue('uid')
	local saveType = luci.http.formvalue('savetype') 
	local resetBtn = luci.http.formvalue('resetBtn')
	--luci.http.write(resetBtn)
	
	index = tonumber(index)

	local config = nybsys.fs_getConfig()

	local mac = config.mac


	if resetBtn == '1' then 
			if type == 'pwm' then 
				config.outputs.pwm[index]['updated'] = updated
				config.outputs.pwm[index].isConfigured = false 
				config.outputs.pwm[index].configuration = nil
			else 
				config.outputs.relay[index]['updated'] = updated
				config.outputs.relay[index].isConfigured = false 
				config.outputs.relay[index].configuration = nil
			end 
	else
		  if type == 'pwm' then 
			config.outputs.pwm[index]['updated'] = updated
			config.outputs.pwm[index].isConfigured = true 
			config.outputs.pwm[index].configuration = {
				defination = name
			}
		 else 
			config.outputs.relay[index]['updated'] = updated
			config.outputs.relay[index].isConfigured = true 
			config.outputs.relay[index].configuration = {
				defination = name
			}
		 end  
	end
	

	nybsys.fs_saveConfig(config)
	luci.http.redirect(luci.dispatcher.build_url("admin/config/io"))
	luci.http.close()
end


function action_logout()
	local dsp = require "luci.dispatcher"
	local utl = require "luci.util"
	local sid = dsp.context.authsession

	if sid then
		utl.ubus("session", "destroy", { ubus_rpc_session = sid })

		luci.http.header("Set-Cookie", "sysauth=%s; expires=%s; path=%s/" %{
			sid, 'Thu, 01 Jan 1970 01:00:00 GMT', dsp.build_url()
		})
	end

	luci.http.redirect(dsp.build_url())
end
