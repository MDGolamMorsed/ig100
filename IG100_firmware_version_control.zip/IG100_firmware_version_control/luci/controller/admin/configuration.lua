--[[
LuCI - Lua Configuration Interface

Copyright 2008 Steven Barth <steven@midlink.org>
Copyright 2008-2011 Jo-Philipp Wich <xm@subsignal.org>
Copyright 2014 Edwin Chen <edwin@dragino.com>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

$Id$
]] --
local nixio = require "nixio"
local fs = require 'nixio.fs'
local io = require 'io'
local json = require 'luci.json'
local nybsys = require 'luci.nybsys'


module('luci.controller.admin.configuration', package.seeall)

function index()
    local uci = luci.model.uci.cursor()
    local string = string
    entry({"admin", "configuratoin", "openvpn"}, call("action_openvpnlog"), _("OpenVPN Log"), 4)
end

function action_openvpnlog()

end 
