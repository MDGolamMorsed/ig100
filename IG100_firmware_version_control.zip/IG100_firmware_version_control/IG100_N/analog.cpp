#include "Arduino.h"
#include "ig.h"
#include "ig_gv.h"
#include "analog.h"


int8_t analogPin[MAX_ANALOG]          = {ANALOG_PIN_IN_0, ANALOG_PIN_IN_1, ANALOG_PIN_IN_2, ANALOG_PIN_IN_3};
int8_t analogIndicatorPin[MAX_ANALOG] = {ANALOG_PIN_IND_0, ANALOG_PIN_IND_1, ANALOG_PIN_IND_2, ANALOG_PIN_IND_3};


void setupAnalog(){
    for (int8_t i = 0; i < MAX_ANALOG; i++) {
        pinMode(analogPin[i], INPUT);               // Analog Pins Assigned as int8_tput
        pinMode(analogIndicatorPin[i], OUTPUT);     // Analog Indicator Pins Assigned as Output
    }
    //Serial.println("From setupAnalog() ...");
}

void setAnalogIndicator(){
    int8_t pinStatus[MAX_ANALOG];
    for (int8_t i = 0; i < MAX_ANALOG; i++){
        pinStatus[i] = EEPROM.read(analogEepromAddress[i]);
        if(pinStatus[i] == 1){
            digitalWrite(analogIndicatorPin[i], HIGH);
        }
        else{
           digitalWrite(analogIndicatorPin[i], LOW); 
        }
    }
}

int8_t setAnalogPin(int8_t pin, int8_t pinSetResetValue){               
    EEPROM.update(analogEepromAddress[pin], pinSetResetValue);
    return ACK;
}

int8_t setAnalogAllPin(int8_t pinSetResetValue){                            
    for (int8_t i = 0; i < MAX_ANALOG; i++){
        EEPROM.update(analogEepromAddress[i], pinSetResetValue);
    }
    return ACK;
}

int8_t getAnalogPin(int8_t pin){             
     int8_t pinStatus = EEPROM.read(analogEepromAddress[pin]);
     if(pinStatus != 1){
        return NACK;
     }
     else{
        return pinStatus;
     }
}

int8_t* getAnalogAllPin(){                        
    static int8_t pinStatus[MAX_ANALOG];           
    for (int8_t i = 0; i < MAX_ANALOG; i++) {
        pinStatus[i] = EEPROM.read(analogEepromAddress[i]); 
        if(pinStatus[i] != 1){
            pinStatus[i] = -1;
        }
    }
    return pinStatus;
}

int8_t getAnalogPinValue(int8_t pin){        
    int8_t pinStatus = EEPROM.read(analogEepromAddress[pin]);
    if(pinStatus == 1){
        //int8_t pinValue = analogRead(analogPin[pin]);
        int8_t pinValue = map(analogRead(analogPin[pin]), 0, 1023, 0, 100);
        return pinValue;
    }
    else{
        return -1;          
    }
}

int8_t* getAnalogAllPinValue(){                       
    int8_t pinStatus ; 
    static int8_t pinValue[MAX_ANALOG];        
    for (int8_t i = 0; i < MAX_ANALOG; i++) {
        pinStatus = EEPROM.read(analogEepromAddress[i]);
        if(pinStatus == 1){
            //pinValue[i] = analogRead(analogPin[i]);
            pinValue[i] = map(analogRead(analogPin[i]), 0, 1023, 0, 100);
        }
        else {
            pinValue[i] = -1;
        }
    }
    return pinValue;
}

void analogIndicator(int8_t pin, int8_t pinSetResetValue){
    digitalWrite(analogIndicatorPin[pin], pinSetResetValue);
}

void analogIndicator(int8_t pinSetResetValue){
    for (int8_t i = 0; i < MAX_ANALOG; i++){
         digitalWrite(analogIndicatorPin[i], pinSetResetValue);
    }
}
