#include "Arduino.h"
#include "ig.h"
#include "ig_gv.h"
#include "send.h"
#include "digital.h"
#include "analog.h"
#include "relay.h"
#include "pwm.h"
#include "interrupt.h"


// Collect incoming ASCII characters until a newline (linefeed) is encountered

void parseCmd()
{
    int8_t stateValue = 0;
    int8_t pinSetResetValue = 0;
    int8_t pin     = 0;
    int8_t cmdChar = 0;
    int8_t i       = 0;
    
    int8_t digit_d = 0;
    int8_t digit_u = 0;

    int8_t  totalPin = MAX_DIGITAL + MAX_ANALOG + MAX_RELAY + MAX_PWM;
    int8_t  replyValue;        
    int8_t* replyArrayPin;   
    int8_t* replyArrayValue;
    int8_t  replyAllPinValue[totalPin];
    int8_t  replyAllPinStatus[totalPin];    
  
    int8_t relayValue[MAX_RELAY];           // for relay initialization
    int8_t pwmValue[MAX_PWM];               // for relay initialization

    char cmdStr[MAX_CMD_BUFFER_SIZE];        // Input buffer

    if (Serial.available() == 0) {
        wdt_reset();            
        return;
    }

    while (true) {
        if (Serial.available() > 0) {
            cmdChar = Serial.read();    // The first byte of incoming serial data available (or -1 if no data is available). Data type: int.
            if (cmdChar == '\n') {      // read incoming command until '\n' (0x10) encountered
                cmdStr[i] = 0;          // string termination char (equivalent to '\0')
                break;
            }
            cmdStr[i] = (char) cmdChar; // for formning array string of char
            i++;
        }
    }

    Serial.println(cmdStr);    //---------------------------
    
    switch(cmdStr[0])
    {
        case 'S':
            if (cmdStr[1] == 'D'){                      
                if(cmdStr[2] == 'A'){                                       // SDAx
                    pinSetResetValue = atoi((char *) &cmdStr[3]);
                    //Serial.print("SDA");
                    //Serial.println(pinSetResetValue);
                    replyValue = setDigitalAllPin(pinSetResetValue);
                    sendValue(replyValue);
                    wdt_reset();            
                }
                else {                                                      // SDnnx  
                    digit_d = cmdStr[2] - '0';
                    digit_u = cmdStr[3] - '0';
                    pin     = digit_d *10 + digit_u;
                    if((pin >= 0) && (pin < MAX_DIGITAL)){
                        pinSetResetValue = atoi((char *) &cmdStr[4]);
                        //Serial.print("SD");
                        //Serial.print(pin);
                        //Serial.println(pinSetResetValue);
                        replyValue = setDigitalPin(pin, pinSetResetValue);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        sendValue(OUT_OF_RANGE);
                        wdt_reset();            
                    }
                }
            }
            else if(cmdStr[1] == 'A'){                   
                if(cmdStr[2] == 'A'){                                       // SAAx
                    pinSetResetValue = atoi((char *) &cmdStr[3]);
                    //Serial.print("SAA");
                    //Serial.println(pinSetResetValue);
                    replyValue = setAnalogAllPin(pinSetResetValue);
                    analogIndicator(pinSetResetValue);  
                    sendValue(replyValue);
                    wdt_reset();            
                }
                else {                                                      // SAnx
                    pin = cmdStr[2] - '0';
                    if((pin >= 0) && (pin < MAX_ANALOG)){
                        pinSetResetValue = atoi((char *) &cmdStr[3]);
                        //Serial.print("SA");
                        //Serial.print(pin);
                        //Serial.println(pinSetResetValue);
                        replyValue = setAnalogPin(pin, pinSetResetValue);
                        analogIndicator(pin, pinSetResetValue); 
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        sendValue(OUT_OF_RANGE);
                        wdt_reset();            
                    }
                }
            }
            else if(cmdStr[1] == 'R'){                   
                if(cmdStr[2] == 'V'){                                       // SRVAx
                    if(cmdStr[3] == 'A'){
                        stateValue = atoi((char *) &cmdStr[4]);
                        //Serial.print("SRVA");
                        //Serial.println(stateValue);
                        replyValue = setRelayAllPinValue(stateValue);
                        sendValue(replyValue);
                        wdt_reset();
                    }
                    else{
                        pin = cmdStr[3] - '0';      // there is a problem in atio(). int atoi(const char *str)
                        if((pin >= 0) && (pin < MAX_RELAY)){                       // SRVnx
                            stateValue = atoi((char *) &cmdStr[4]);
                            //Serial.print("SRV");
                            //Serial.print(pin);
                            //Serial.println(stateValue);
                            replyValue = setRelayPinValue(pin, stateValue);
                            sendValue(replyValue);
                            wdt_reset();            
                        }
                        else {
                            sendValue(OUT_OF_RANGE);
                            wdt_reset();            
                        }
                    }
                }                                                           // SRAx
                else if(cmdStr[2] == 'A'){
                    pinSetResetValue = atoi((char *) &cmdStr[3]);
                    //Serial.print("SRA");
                    //Serial.println(pinSetResetValue);
                    replyValue = setRelayAllPin(pinSetResetValue);
                    relayIndicator(pinSetResetValue);   
                    sendValue(replyValue);
                    wdt_reset();            
                }
                else {                                                      // SRnx
                    pin = cmdStr[2] - '0';
                    if((pin >= 0) && (pin < MAX_RELAY)){
                        pinSetResetValue = atoi((char *) &cmdStr[3]);
                        //Serial.print("SR");
                        //Serial.print(pin);
                        //Serial.println(pinSetResetValue);
                        replyValue = setRelayPin(pin, pinSetResetValue);
                        relayIndicator(pin, pinSetResetValue);    
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        sendValue(OUT_OF_RANGE);
                        wdt_reset();            
                    }
                }
            }
            else if(cmdStr[1] == 'P'){                   
                if(cmdStr[2] == 'V'){                                       // SPVAx
                    if(cmdStr[3] == 'A'){
                        stateValue = atoi((char *) &cmdStr[4]);
                        //Serial.print("SPVA");
                        //Serial.println(stateValue);
                        replyValue = setPwmAllPinValue(stateValue);
                        sendValue(replyValue);
                        wdt_reset();
                    }
                    else{
                        pin = cmdStr[3] - '0';
                        if((pin >= 0) && (pin < MAX_PWM)){                      // SPVnx
                            stateValue = atoi((char *) &cmdStr[4]);
                            //Serial.print("SPV");
                            //Serial.print(pin);
                            //Serial.println(stateValue);
                            replyValue = setPwmPinValue(pin, stateValue);
                            sendValue(replyValue);
                            wdt_reset();            
                        }
                        else {
                            sendValue(OUT_OF_RANGE);
                            wdt_reset();            
                        }
                    }
                }
                else if(cmdStr[2] == 'A'){                                  // SPAx
                    pinSetResetValue = atoi((char *) &cmdStr[3]);
                    //Serial.print("SPA");
                    //Serial.println(pinSetResetValue);
                    replyValue = setPwmAllPin(pinSetResetValue);
                    pwmIndicator(pinSetResetValue);     
                    sendValue(replyValue);
                    wdt_reset();            
                }
                else {                                                      // SPnx
                    pin = cmdStr[2] - '0';
                    if((pin >= 0) && (pin < MAX_PWM)){
                        pinSetResetValue = atoi((char *) &cmdStr[3]);
                        //Serial.print("SP");
                        //Serial.print(pin);
                        //Serial.println(pinSetResetValue);
                        replyValue = setPwmPin(pin, pinSetResetValue);
                        pwmIndicator(pin, pinSetResetValue);  
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        sendValue(OUT_OF_RANGE);
                        wdt_reset();            
                    }
                }
            }
            else if(cmdStr[1] == 'I'){                   
                if(cmdStr[2] == 'A'){                                       // SIAx
                    pinSetResetValue = atoi((char *) &cmdStr[3]);
                    //Serial.print("SIA");
                    //Serial.println(pinSetResetValue);
                    replyValue = setInterruptAllPin(pinSetResetValue);
                    sendValue(replyValue);
                    wdt_reset();            // Reset the watchdog
                }
                else {                                                      // SInnx
                    digit_d = cmdStr[2] - '0';
                    digit_u = cmdStr[3] - '0';
                    pin     = digit_d *10 + digit_u;
                    if((pin >= 0) && (pin < MAX_INTERRUPT)){
                        pinSetResetValue = atoi((char *) &cmdStr[4]);
                        //Serial.print("SI");
                        //Serial.print(pin);
                        //Serial.println(pinSetResetValue);
                        replyValue = setInterruptPin(pin, pinSetResetValue);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        sendValue(OUT_OF_RANGE);
                        wdt_reset();            
                    }
                }
            }
            else{                                                           // UNKNOWN_CMD
                sendValue(UNKNWON_CMD);    
                wdt_reset();            
            }
            break;
            
        case 'G':
            if(cmdStr[1] == 'D'){                    
                if(cmdStr[2] == 'T'){                                       // GDTn
                    pin = atoi((char *) &cmdStr[3]);
                    if((pin >= 0) && (pin < MAX_DIGITAL)){
                        //Serial.print("GDT");
                        //Serial.println(pin);
                        replyValue = getDigitalPinTemperature(pin);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        sendValue(OUT_OF_RANGE);
                        wdt_reset();            
                    }
                }
                else if(cmdStr[2] == 'H'){                                  // GDHn
                    pin = atoi((char *) &cmdStr[3]);
                    if((pin >= 0) && (pin < MAX_DIGITAL)){
                        //Serial.print("GDH");
                        //Serial.println(pin);
                        replyValue = getDigitalPinHumidity(pin);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        sendValue(OUT_OF_RANGE);
                        wdt_reset();            
                    }
                }
                else if(cmdStr[2] == 'V'){                                  // GDVA
                    if(cmdStr[3] == 'A'){
                        //Serial.println("GDVA");
                        replyArrayValue = getDigitalAllPinValue();
                        sendValue(MAX_DIGITAL, replyArrayValue);
                        wdt_reset();            
                    }
                    else{                                                   // GDVn
                        pin = atoi((char *) &cmdStr[3]);
                        if((pin >= 0) && (pin < MAX_DIGITAL)){
                            //Serial.print("GDV");
                            //Serial.println(pin);
                            replyValue = getDigitalPinValue(pin);
                            sendValue(replyValue);
                            wdt_reset();            
                        }
                        else{
                            sendValue(OUT_OF_RANGE);
                            wdt_reset();            
                        }
                    }
                }
                else if(cmdStr[2] == 'A'){                                  // GDA
                    //Serial.println("GDA");
                    replyArrayPin = getDigitalAllPin();
                    sendValue(MAX_DIGITAL, replyArrayPin);
                    wdt_reset();            
                }
                else {                                                      // GDn
                    pin = atoi((char *) &cmdStr[2]);
                    if((pin >= 0) && (pin < MAX_DIGITAL)){
                        //Serial.print("GD");
                        //Serial.println(pin);
                        replyValue = getDigitalPin(pin);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        sendValue(OUT_OF_RANGE);
                        wdt_reset();            
                    }
                }
            }
            else if(cmdStr[1] == 'A'){
                if(cmdStr[2] == 'V'){                                       // GAVA
                    if(cmdStr[3] == 'A'){
                        //Serial.println("GAVA");
                        replyArrayValue = getAnalogAllPinValue();
                        sendValue(MAX_ANALOG, replyArrayValue);
                        wdt_reset();            
                    }
                    else{                                                   // GAVn
                        pin = atoi((char *) &cmdStr[3]);
                        if((pin >= 0) && (pin < MAX_ANALOG)){
                            //Serial.print("GAV");
                            //Serial.println(pin);
                            replyValue = getAnalogPinValue(pin);
                            sendValue(replyValue);
                            wdt_reset();            
                        }
                        else{
                            sendValue(OUT_OF_RANGE);
                            wdt_reset();            
                        }
                    }
                }
                else if(cmdStr[2] == 'A'){                                  // GAA
                    //Serial.println("GAA");
                    replyArrayPin = getAnalogAllPin();
                    sendValue(MAX_ANALOG, replyArrayPin);
                    wdt_reset();            
                }
                else {                                                      // GAn
                    pin = atoi((char *) &cmdStr[2]);
                    if((pin >= 0) && (pin < MAX_ANALOG)){
                        //Serial.print("GA");
                        //Serial.println(pin);
                        replyValue = getAnalogPin(pin);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        sendValue(OUT_OF_RANGE);
                        wdt_reset();            
                    }
                }
            }
            else if(cmdStr[1] == 'R'){
                if(cmdStr[2] == 'V'){                                       // GRVA
                    if(cmdStr[3] == 'A'){
                        //Serial.println("GRVA");
                        replyArrayValue = getRelayAllPinValue();
                        sendValue(MAX_RELAY, replyArrayValue);
                        wdt_reset();           
                    }
                    else{                                                   // GRVn
                        pin = atoi((char *) &cmdStr[3]);
                        if((pin >= 0) && (pin < MAX_RELAY)){
                            //Serial.print("GRV");
                            //Serial.println(pin);
                            replyValue = getRelayPinValue(pin);
                            sendValue(replyValue);
                            wdt_reset();            
                        }
                        else{
                            sendValue(OUT_OF_RANGE);
                            wdt_reset();            
                        }
                    }
                }
                else if(cmdStr[2] == 'A'){                                  // GRA 
                    //Serial.println("GRA");
                    replyArrayPin = getRelayAllPin();
                    sendValue(MAX_RELAY, replyArrayPin);
                    wdt_reset();           
                }
                else {                                                      // GRn
                    pin = atoi((char *) &cmdStr[2]);
                    if((pin >= 0) && (pin < MAX_RELAY)){
                        //Serial.print("GR");
                        //Serial.println(pin);
                        replyValue = getRelayPin(pin);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        sendValue(OUT_OF_RANGE);
                        wdt_reset();            
                    }
                }
            }
            else if(cmdStr[1] == 'P'){
                if(cmdStr[2] == 'V'){                                       // GPVA
                    if(cmdStr[3] == 'A'){
                        //Serial.println("GPVA");
                        replyArrayValue = getPwmAllPinValue();
                        sendValue(MAX_PWM, replyArrayValue);
                        wdt_reset();            
                    }
                    else{                                                   // GPVn
                        pin = atoi((char *) &cmdStr[3]);
                        if((pin >= 0) && (pin < MAX_PWM)){
                            //Serial.print("GPV");
                            //Serial.println(pin);
                            replyValue = getPwmPinValue(pin);
                            sendValue(replyValue);
                            wdt_reset();            
                        }
                        else{
                            sendValue(OUT_OF_RANGE);
                            wdt_reset();            
                        }
                    }
                }
                else if(cmdStr[2] == 'A'){                                  // GPA
                    //Serial.println("GPA");
                    replyArrayPin = getPwmAllPin();
                    sendValue(MAX_PWM, replyArrayPin);
                    wdt_reset();            
                }
                else {                                                      // GPn
                    pin = atoi((char *) &cmdStr[2]);
                    if((pin >= 0) && (pin < MAX_PWM)){
                        //Serial.print("GP");
                        //Serial.println(pin);
                        replyValue = getPwmPin(pin);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        sendValue(OUT_OF_RANGE);
                        wdt_reset();            
                    }
                }
            }
            else if(cmdStr[1] == 'I'){
                if(cmdStr[2] == 'A'){                                       // GIA
                    //Serial.println("GIA"); 
                    replyArrayPin = getInterruptAllPin();
                    sendValue(MAX_DIGITAL, replyArrayPin);
                    wdt_reset();           
                }
                else {                                                      // GIn
                    pin = atoi((char *) &cmdStr[2]);
                    if((pin >= 0) && (pin <= MAX_INTERRUPT)){
                        //Serial.print("GI");
                        //Serial.println(pin);
                        replyValue = getInterruptPin(pin);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        sendValue(OUT_OF_RANGE);
                        wdt_reset();            
                    }
                }
            }
            else if(cmdStr[1] == 'M'){                                      // GM
                //Serial.println("GM");
                //-----------------------
                //-----------------------
                wdt_reset();            // Reset the watchdog
            }
            else if(cmdStr[1] == 'C'){                                      // GC
                //Serial.println("GC");
                //-----------------------
                //-----------------------
                wdt_reset();            // Reset the watchdog
            }
            else {                                                          // UNKNOWN_CMD
                sendValue(UNKNWON_CMD);    
                wdt_reset();            
            }
            break;
            
        case 'I':
            if(cmdStr[1] == 'R'){                                           // IRxxxx           THERE IS LSB & MSB ISSUE TO CONFIRM
                for(int8_t i = 0; i < MAX_RELAY; i++){
                        relayValue[i] = cmdStr[i+2] - '0';
                    }
                for(int8_t i = 0; i < MAX_RELAY; i++){
                        replyValue = setRelayPinValue(i, relayValue[i]);
                    }
                sendValue(ACK);
                //sendValue('j');
                wdt_reset();            
            }
            else if(cmdStr[1] == 'P'){                                      // IPxxxx
                for(int8_t i = 0, j = 0; i < MAX_PWM; i++, j = j+2){
                        pwmValue[i] = (cmdStr[i+2+j] - '0') *100 + 
                                      (cmdStr[i+3+j] - '0') * 10 + 
                                      (cmdStr[i+4+j] - '0') * 1;
                        //Serial.println(pwmValue[i]);
                    }
                for(int8_t i = 0; i < MAX_PWM; i++){
                        replyValue = setPwmPinValue(i, pwmValue[i]);
                    }
                sendValue(ACK);
                //sendValue('k');
                wdt_reset();           
            }
            else {                                                          // UNKNOWN_CMD
                sendValue(UNKNWON_CMD);    
                wdt_reset();            
            }
            break;

        case 'C':
            if(cmdStr[1] == 'S'){                                           // CSRx
                if(cmdStr[2] == 'R'){
                    pinSetResetValue = atoi((char *) &cmdStr[3]);
                    //Serial.print("CSR");
                    //Serial.println(pinSetResetValue);  
                    replyValue = setDigitalAllPin(pinSetResetValue);
                    replyValue = setAnalogAllPin(pinSetResetValue);
                    analogIndicator(pinSetResetValue);
                    replyValue = setRelayAllPin(pinSetResetValue);
                    relayIndicator(pinSetResetValue);
                    replyValue = setPwmAllPin(pinSetResetValue);
                    pwmIndicator(pinSetResetValue);     
                    sendValue(replyValue);  
                    wdt_reset(); 
                }
                else{                                                       // UNKNOWN_CMD
                    sendValue(UNKNWON_CMD);    
                    wdt_reset();  
                }
            }
            else if(cmdStr[1] == 'P'){                                      // CPA
                if(cmdStr[2] == 'A'){
                    //Serial.println("CPA");
                    int8_t i = 0;
                    int8_t j = 0;
                    replyArrayPin = getDigitalAllPin();
                    for(i = 0, j = j; i < MAX_DIGITAL; i++, j++){
                        replyAllPinStatus[j] = replyArrayPin[i];
                    }
                    replyArrayPin = getAnalogAllPin();
                    for(i = 0, j = j; i < MAX_ANALOG; i++, j++){
                        replyAllPinStatus[j] = replyArrayPin[i];
                    }
                    replyArrayPin = getRelayAllPin();
                    for(i = 0, j = j; i < MAX_RELAY; i++, j++){
                        replyAllPinStatus[j] = replyArrayPin[i];
                    }
                    replyArrayPin = getPwmAllPin();
                    for(i = 0, j = j; i < MAX_PWM; i++, j++){
                        replyAllPinStatus[j] = replyArrayPin[i];
                    }
                    sendValue(totalPin, replyAllPinStatus);    
                    wdt_reset(); 
                }
                else{                                                       // UNKNOWN_CMD
                    sendValue(UNKNWON_CMD);    
                    wdt_reset(); 
                }
            }
            else if(cmdStr[1] == 'V'){                                      // CVA
                if(cmdStr[2] == 'A'){
                    //Serial.println("CVA");
                    int8_t i = 0;
                    int8_t j = 0;
                    replyArrayValue = getDigitalAllPinValue();
                    for(i = 0, j = j; i < MAX_DIGITAL; i++, j++){
                        replyAllPinValue[j] = replyArrayValue[i];
                    }
                    replyArrayValue = getAnalogAllPinValue();
                    for(i = 0, j = j; i < MAX_ANALOG; i++, j++){
                        replyAllPinValue[j] = replyArrayValue[i];
                    }
                    replyArrayValue = getRelayAllPinValue();
                    for(i = 0, j = j; i < MAX_RELAY; i++, j++){
                        replyAllPinValue[j] = replyArrayValue[i];
                    }
                    replyArrayValue = getPwmAllPinValue();
                    for(i = 0, j = j; i < MAX_PWM; i++, j++){
                        replyAllPinValue[j] = replyArrayValue[i];
                    }
                    sendValue(totalPin, replyAllPinValue);    
                    wdt_reset(); 
                }
                else{                                                       // UNKNOWN_CMD
                    sendValue(UNKNWON_CMD);    
                    wdt_reset(); 
                } 
            }
            else {                                                          // UNKNOWN_CMD
                sendValue(UNKNWON_CMD);    
                wdt_reset(); 
            }
            break;
            
        default:                                                            // UNKNOWN_CMD
            sendValue(UNKNWON_CMD);   
            wdt_reset();            
            break;
    }
}

















/*
 #include "Arduino.h"
#include "ig.h"
#include "ig_gv.h"
#include "send.h"
#include "digital.h"
#include "analog.h"
#include "relay.h"
#include "pwm.h"
#include "interrupt.h"

// Collect incoming ASCII characters until a newline (linefeed) is encountered

void parseCmd()
{
    int stateValue = 0;
    int pinSetResetValue = 0;
    int achan  = 0;
    int inchar = 0;
    int i      = 0;
    int slen   = 0;

    int  replyValue;        //----
    int* replyArrayValue;   //---- 


    char instr[MAXINSZ];        // Input buffer

    if (Serial.available() == 0) {
        wdt_reset();            // Reset the watchdog
        return;
    }

    while (true) {
        if (Serial.available() > 0) {
            inchar = Serial.read();
            // read incoming command until '\n' (0x10) encountered
            if (inchar == 10) {
                instr[i] = 0;
                slen = i;
                break;
            }

            // prevent buffer overflow
            if (i >= MAXINSZ-1) {
                instr[i] = 0;
                slen = i;
                break;
            }

            instr[i] = (char) inchar;
            i++;
        }
    }
    

    //Serial.write(instr, slen);
    //Serial.println("...");

    switch(instr[0])
    {
        case 'S':
            if (instr[1] == 'D'){                      
                if(instr[2] == 'A'){                                // SDAx
                    pinSetResetValue = atoi((char *) &instr[3]);
                    Serial.print("SDA");
                    Serial.println(pinSetResetValue);
                    replyValue = setDigitalAllPin(pinSetResetValue);
                    sendValue(replyValue);
                    wdt_reset();            
                }
                else {                                              // SDnx
                    //achan = atoi((char *) &instr[2]);
                    achan = instr[2] - '0';
                    if((achan >= 0) && (achan <= 11)){
                        pinSetResetValue = atoi((char *) &instr[3]);
                        Serial.print("SD");
                        Serial.print(achan);
                        Serial.println(pinSetResetValue);
                        replyValue = setDigitalPin(achan, pinSetResetValue);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        Serial.println("Port out of Range!!!");
                        wdt_reset();            
                    }
                }
            }
            else if(instr[1] == 'A'){                   
                if(instr[2] == 'A'){                                // SAAx
                    pinSetResetValue = atoi((char *) &instr[3]);
                    Serial.print("SAA");
                    Serial.println(pinSetResetValue);
                    replyValue = setAnalogAllPin(pinSetResetValue);
                    analogIndicator(pinSetResetValue);  //---------------------------------------------------------------------
                    sendValue(replyValue);
                    wdt_reset();            
                }
                else {                                              // SAnx
                    //achan = atoi((char *) &instr[2]);
                    achan = instr[2] - '0';
                    if((achan >= 0) && (achan <= 3)){
                        pinSetResetValue = atoi((char *) &instr[3]);
                        Serial.print("SA");
                        Serial.print(achan);
                        Serial.println(pinSetResetValue);
                        replyValue = setAnalogPin(achan, pinSetResetValue);
                        analogIndicator(achan, pinSetResetValue); //------------------------------------------------------------
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        Serial.println("Port out of Range!!!");
                        wdt_reset();            
                    }
                }
            }
            else if(instr[1] == 'R'){                   
                if(instr[2] == 'V'){                                // SRVAx
                    if(instr[3] == 'A'){
                        stateValue = atoi((char *) &instr[4]);
                        Serial.print("SRVA");
                        Serial.println(stateValue);
                        replyValue = setRelayAllPinValue(stateValue);
                        sendValue(replyValue);
                        wdt_reset();
                    }
                    else{
                        //achan = atoi((char *) &instr[3]); // there is a problem in atio(). int atoi(const char *str)
                        achan = instr[3] - '0';
                        if((achan >= 0) && (achan <= 3)){               // SRVnx
                            stateValue = atoi((char *) &instr[4]);
                            Serial.print("SRV");
                            Serial.print(achan);
                            Serial.println(stateValue);
                            replyValue = setRelayPinValue(achan, stateValue);
                            sendValue(replyValue);
                            wdt_reset();            
                        }
                        else {
                            Serial.println("Port out of Range!!!");
                            wdt_reset();            
                        }
                    }
                }                                                   // SRAx
                else if(instr[2] == 'A'){
                    pinSetResetValue = atoi((char *) &instr[3]);
                    Serial.print("SRA");
                    Serial.println(pinSetResetValue);
                    replyValue = setRelayAllPin(pinSetResetValue);
                    relayIndicator(pinSetResetValue);   //-------------------------------------------------------------
                    sendValue(replyValue);
                    wdt_reset();            
                }
                else {                                              // SRnx
                    achan = atoi((char *) &instr[2]);
                    achan = instr[2] - '0';
                    if((achan >= 0) && (achan <= 3)){
                        pinSetResetValue = atoi((char *) &instr[3]);
                        Serial.print("SR");
                        Serial.print(achan);
                        Serial.println(pinSetResetValue);
                        replyValue = setRelayPin(achan, pinSetResetValue);
                        relayIndicator(achan, pinSetResetValue);    //-------------------------------------------------
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        Serial.println("Port out of Range!!!");
                        wdt_reset();            
                    }
                }
            }
            else if(instr[1] == 'P'){                   
                if(instr[2] == 'V'){                                // SPVAx
                    if(instr[3] == 'A'){
                        stateValue = atoi((char *) &instr[4]);
                        Serial.print("SPVA");
                        Serial.println(stateValue);
                        replyValue = setPwmAllPinValue(stateValue);
                        sendValue(replyValue);
                        wdt_reset();
                    }
                    else{
                        //achan = atoi((char *) &instr[3]);
                        achan = instr[3] - '0';
                        if((achan >= 0) && (achan <=3 )){               // SPVnx
                            stateValue = atoi((char *) &instr[4]);
                            Serial.print("SPV");
                            Serial.print(achan);
                            Serial.println(stateValue);
                            replyValue = setPwmPinValue(achan, stateValue);
                            sendValue(replyValue);
                            wdt_reset();            
                        }
                        else {
                            Serial.println("Port out of Range!!!");
                            wdt_reset();            
                        }
                    }
                }
                else if(instr[2] == 'A'){                           // SPAx
                    pinSetResetValue = atoi((char *) &instr[3]);
                    Serial.print("SPA");
                    Serial.println(pinSetResetValue);
                    replyValue = setPwmAllPin(pinSetResetValue);
                    pwmIndicator(pinSetResetValue);     //----------------------------------------------------------
                    sendValue(replyValue);
                    wdt_reset();            
                }
                else {                                              // SPnx
                    achan = instr[2] - '0';
                    if((achan >= 0) && (achan <= 3)){
                        pinSetResetValue = atoi((char *) &instr[3]);
                        Serial.print("SP");
                        Serial.print(achan);
                        Serial.println(pinSetResetValue);
                        replyValue = setPwmPin(achan, pinSetResetValue);
                        pwmIndicator(achan, pinSetResetValue);  //--------------------------------------------------
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        Serial.println("Port out of Range!!!");
                        wdt_reset();            
                    }
                }
            }
            else if(instr[1] == 'I'){                   
                if(instr[2] == 'A'){                                // SIAx
                    pinSetResetValue = atoi((char *) &instr[3]);
                    Serial.print("SIA");
                    Serial.println(pinSetResetValue);
                    //-----------------------
                    //-----------------------
                    wdt_reset();            // Reset the watchdog
                }
                else {                                              // SInx
                    //achan = atoi((char *) &instr[2]);
                    achan = instr[2] - '0';           
                    if((achan >= 0) && (achan <= 3)){
                        pinSetResetValue = atoi((char *) &instr[3]);
                        Serial.print("SI");
                        Serial.print(achan);
                        Serial.println(pinSetResetValue);
                        //-----------------------
                        //-----------------------
                        wdt_reset();            // Reset the watchdog
                    }
                    else {
                        Serial.println("Port out of Range!!!");
                        wdt_reset();            // Reset the watchdog
                    }
                }
            }
            else{                                                   // BAD CMD
                Serial.println("BAD CMD of set");
                wdt_reset();            // Reset the watchdog
            }
            break;
            
        case 'G':
            if(instr[1] == 'D'){                    
                if(instr[2] == 'T'){                                // GDTn
                    achan = atoi((char *) &instr[3]);
                    if((achan >= 0) && (achan <= 11)){
                        Serial.print("GDT");
                        Serial.println(achan);
                        //getDigitalTempPin(achan);
                        replyValue = getDigitalTempPin(achan);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        Serial.println("Port out of Range!!!");
                        wdt_reset();            
                    }
                }
                else if(instr[2] == 'H'){                           // GDHn
                    achan = atoi((char *) &instr[3]);
                    if((achan >= 0) && (achan <= 11)){
                        Serial.print("GDH");
                        Serial.println(achan);
                        //getDigitalHumPin(achan);
                        replyValue = getDigitalHumPin(achan);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        Serial.println("Port out of Range!!!");
                        wdt_reset();            
                    }
                }
                else if(instr[2] == 'V'){                           // GDVA
                    if(instr[3] == 'A'){
                        Serial.println("GDVA");
                        replyArrayValue = getDigitalAllPinValue();
                        sendValue(MAX_DIGITAL, replyArrayValue);
                        wdt_reset();            
                    }
                    else{                                           // GDVn
                        achan = atoi((char *) &instr[3]);
                        if((achan >= 0) && (achan <= 11)){
                            Serial.print("GDV");
                            Serial.println(achan);
                            replyValue = getDigitalPinValue(achan);
                            sendValue(replyValue);
                            wdt_reset();            
                        }
                        else{
                            Serial.println("Port out of Range!!!");
                            wdt_reset();            
                        }
                    }
                }
                else if(instr[2] == 'A'){                           // GDA
                    Serial.println("GDA");
                    replyArrayValue = getDigitalAllPin();
                    sendValue(MAX_DIGITAL, replyArrayValue);
                    wdt_reset();            
                }
                else {                                              // GDn
                    achan = atoi((char *) &instr[2]);
                    if((achan >= 0) && (achan <= 11)){
                        Serial.print("GD");
                        Serial.println(achan);
                        replyValue = getDigitalPin(achan);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        Serial.println("Port out of Range!!!");
                        wdt_reset();            
                    }
                }
            }
            else if(instr[1] == 'A'){
                if(instr[2] == 'V'){                           // GAVA
                    if(instr[3] == 'A'){
                        Serial.println("GAVA");
                        replyArrayValue = getAnalogAllPinValue();
                        sendValue(MAX_ANALOG, replyArrayValue);
                        wdt_reset();            
                    }
                    else{                                           // GAVn
                        achan = atoi((char *) &instr[3]);
                        if((achan >= 0) && (achan <= 3)){
                            Serial.print("GAV");
                            Serial.println(achan);
                            replyValue = getAnalogPinValue(achan);
                            sendValue(replyValue);
                            wdt_reset();            
                        }
                        else{
                            Serial.println("Port out of Range!!!");
                            wdt_reset();            
                        }
                    }
                }
                else if(instr[2] == 'A'){                           // GAA
                    Serial.println("GAA");
                    replyArrayValue = getAnalogAllPin();
                    sendValue(MAX_ANALOG, replyArrayValue);
                    wdt_reset();            
                }
                else {                                              // GAn
                    achan = atoi((char *) &instr[2]);
                    if((achan >= 0) && (achan <= 3)){
                        Serial.print("GA");
                        Serial.println(achan);
                        replyValue = getAnalogPin(achan);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        Serial.println("Port out of Range!!!");
                        wdt_reset();            
                    }
                }
            }
            else if(instr[1] == 'R'){
                if(instr[2] == 'V'){                                // GRVA
                    if(instr[3] == 'A'){
                        Serial.println("GRVA");
                        replyArrayValue = getRelayAllPinValue();
                        sendValue(MAX_RELAY, replyArrayValue);
                        wdt_reset();           
                    }
                    else{                                           // GRVn
                        achan = atoi((char *) &instr[3]);
                        if((achan >= 0) && (achan <= 3)){
                            Serial.print("GRV");
                            Serial.println(achan);
                            replyValue = getRelayPinValue(achan);
                            sendValue(replyValue);
                            wdt_reset();            
                        }
                        else{
                            Serial.println("Port out of Range!!!");
                            wdt_reset();            
                        }
                    }
                }
                else if(instr[2] == 'A'){                           // GRA 
                    Serial.println("GRA");
                    replyArrayValue = getRelayAllPin();
                    sendValue(MAX_RELAY, replyArrayValue);
                    wdt_reset();           
                }
                else {                                              // GRn
                    achan = atoi((char *) &instr[2]);
                    if((achan >= 0) && (achan <= 3)){
                        Serial.print("GR");
                        Serial.println(achan);
                        replyValue = getRelayPin(achan);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        Serial.println("Port out of Range!!!");
                        wdt_reset();            
                    }
                }
            }
            else if(instr[1] == 'P'){
                if(instr[2] == 'V'){                                // GPVA
                    if(instr[3] == 'A'){
                        Serial.println("GPVA");
                        replyArrayValue = getPwmAllPinValue();
                        sendValue(MAX_PWM, replyArrayValue);
                        wdt_reset();            
                    }
                    else{                                           // GPVn
                        achan = atoi((char *) &instr[3]);
                        if((achan >= 0) && (achan <= 3)){
                            Serial.print("GPV");
                            Serial.println(achan);
                            replyValue = getPwmPinValue(achan);
                            sendValue(replyValue);
                            wdt_reset();            
                        }
                        else{
                            Serial.println("Port out of Range!!!");
                            wdt_reset();            
                        }
                    }
                }
                else if(instr[2] == 'A'){                           // GPA
                    Serial.println("GPA");
                    replyArrayValue = getPwmAllPin();
                    sendValue(MAX_PWM, replyArrayValue);
                    wdt_reset();            
                }
                else {                                              // GPn
                    achan = atoi((char *) &instr[2]);
                    if((achan >= 0) && (achan <= 3)){
                        Serial.print("GP");
                        Serial.println(achan);
                        replyValue = getPwmPin(achan);
                        sendValue(replyValue);
                        wdt_reset();            
                    }
                    else {
                        Serial.println("Port out of Range!!!");
                        wdt_reset();            
                    }
                }
            }
            else if(instr[1] == 'I'){
                if(instr[2] == 'A'){                                // GIA
                    Serial.println("GIA"); 
                    //-----------------------
                    //-----------------------
                    wdt_reset();            // Reset the watchdog
                }
                else {                                              // GIn
                    achan = atoi((char *) &instr[2]);
                    if((achan >= 0) && (achan <= 3)){
                        Serial.print("GI");
                        Serial.println(achan);
                        //-----------------------
                        //-----------------------
                        wdt_reset();            // Reset the watchdog
                    }
                    else {
                        Serial.println("Port out of Range!!!");
                        wdt_reset();            // Reset the watchdog
                    }
                }
            }
            else if(instr[1] == 'M'){                               // GM
                Serial.println("GM");
                //-----------------------
                //-----------------------
                wdt_reset();            // Reset the watchdog
            }
            else if(instr[1] == 'C'){                               // GC
                Serial.println("GC");
                //-----------------------
                //-----------------------
                wdt_reset();            // Reset the watchdog
            }
            else if((instr[1] == 'V') && (instr[2] == 'A')){        // GVA  -- yasir vai
                Serial.println("GVA");
                //-----------------------
                //-----------------------
                wdt_reset();            // Reset the watchdog
            }
            else {                                                  // BAD CMD
                Serial.println("BAD CMD of get");
                //-----------------------
                //-----------------------
                wdt_reset();            // Reset the watchdog
            }
            break;
            
        case 'I':
            if(instr[1] == 'R'){                                    // IRxxxx
                Serial.println("IRxxxx");
                initializeRelayAll();
                //-----------------------
                wdt_reset();            // Reset the watchdog
            }
            else if(instr[1] == 'P'){                               // IPxxxx
                Serial.println("IPxxxx");
                initializePwmAll();
                //-----------------------
                wdt_reset();            // Reset the watchdog
            }
            else {                                                  // BAD CMD
                Serial.println("BAD CMD of initialize");
                wdt_reset();            // Reset the watchdog
            }
            break;
            
        default:
            Serial.println("Wrong cmd !!!");                        // BAD CMD
            wdt_reset();            // Reset the watchdog
            break;
    }
}
 */
