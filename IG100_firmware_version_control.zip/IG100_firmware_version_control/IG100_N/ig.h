 #ifndef IGDEFS_H
#define IGDEFS_H

#define DIGITAL_PIN_IN_0     2      // Digital INPUT
#define DIGITAL_PIN_IN_1    10      // Digital INPUT
#define DIGITAL_PIN_IN_2    49      // Digital INPUT
#define DIGITAL_PIN_IN_3    47      // Digital INPUT
#define DIGITAL_PIN_IN_4    21      // Digital INPUT // Interrupt Pin
#define DIGITAL_PIN_IN_5    19      // Digital INPUT // Interrupt Pin
#define DIGITAL_PIN_IN_6    53      // Digital INPUT
#define DIGITAL_PIN_IN_7    11      // Digital INPUT
#define DIGITAL_PIN_IN_8    48      // Digital INPUT
#define DIGITAL_PIN_IN_9    46      // Digital INPUT
#define DIGITAL_PIN_IN_10   20      // Digital INPUT // Interrupt Pin
#define DIGITAL_PIN_IN_11   18      // Digital INPUT // Interrupt Pin

#define ANALOG_PIN_IN_0    A15      // ANALOG INPUT
#define ANALOG_PIN_IN_1    A12      // ANALOG INPUT
#define ANALOG_PIN_IN_2    A14      // ANALOG INPUT
#define ANALOG_PIN_IN_3    A13      // ANALOG INPUT

#define ANALOG_PIN_IND_0    37      // ANALOG INDICATOR
#define ANALOG_PIN_IND_1    40      // ANALOG INDICATOR
#define ANALOG_PIN_IND_2    41      // ANALOG INDICATOR
#define ANALOG_PIN_IND_3    38      // ANALOG INDICATOR

#define RELAY_PIN_OUT_0     25      // RELAY OUTPUT
#define RELAY_PIN_OUT_1     26      // RELAY OUTPUT
#define RELAY_PIN_OUT_2     27      // RELAY OUTPUT
#define RELAY_PIN_OUT_3     28      // RELAY OUTPUT

#define RELAY_PIN_IND_0     32      // RELAY INDICATOR
#define RELAY_PIN_IND_1     31      // RELAY INDICATOR
#define RELAY_PIN_IND_2     30      // RELAY INDICATOR
#define RELAY_PIN_IND_3     39      // RELAY INDICATOR

#define PWM_PIN_OUT_0        9      // PWM OUTPUT
#define PWM_PIN_OUT_1        8      // PWM OUTPUT
#define PWM_PIN_OUT_2        7      // PWM OUTPUT
#define PWM_PIN_OUT_3        6      // PWM OUTPUT

#define PWM_PIN_IND_0       36      // PWM INDICATOR
#define PWM_PIN_IND_1       34      // PWM INDICATOR
#define PWM_PIN_IND_2       33      // PWM INDICATOR
#define PWM_PIN_IND_3       35      // PWM INDICATOR

#define INT_PIN_IN_0        21      // Digital INPUT   // Digital pin indexing concept is ommited
#define INT_PIN_IN_1        19      // Digital INPUT
#define INT_PIN_IN_2        20      // Digital INPUT    
#define INT_PIN_IN_3        18      // Digital INPUT

#define CAN_PIN             12      // CAN bus IO
#define MOD_TX              33      // Dummy not sure yet
#define MOD_RX              44      // Dummy not sure yet


#define MAX_DIGITAL         12      // maximum digital input
#define MAX_ANALOG           4      // maximum analog  input
#define MAX_RELAY            4      // maximum relay   input
#define MAX_PWM              4      // maximum pwm     input
#define MAX_INTERRUPT       12      // maximum pwm     input

#define ACK                  1      // Operation sucess code
#define NACK                -1      // Operation error code (port not configured)
#define OUT_OF_RANGE        -2      // Port out of range
#define UNKNWON_CMD         -3      // Unknown CMD (not listed in CMD list)

#define MAX_CMD_BUFFER_SIZE 12      // input buffer size

#endif
