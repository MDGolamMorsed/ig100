#ifndef IGANALOG_H
#define IGANALOG_H

void    setupAnalog();
void    setAnalogIndicator();
int8_t  setAnalogPin(int8_t pin, int8_t pinSetResetValue);   
int8_t  setAnalogAllPin(int8_t pinSetResetValue);                
int8_t  getAnalogPin(int8_t pin);         
int8_t* getAnalogAllPin();                    
int8_t  getAnalogPinValue(int8_t pin);    
int8_t* getAnalogAllPinValue();               
void    analogIndicator(int8_t pin, int8_t pinSetResetValue);
void    analogIndicator(int8_t pinSetResetValue);

#endif
