#include "Arduino.h"
#include "ig.h"
#include "ig_gv.h"
#include "relay.h"

int8_t relayPinValue[MAX_RELAY]        = {0, 0, 0, 0};
int8_t relayPin[MAX_RELAY]             = {RELAY_PIN_OUT_0, RELAY_PIN_OUT_1, RELAY_PIN_OUT_2, RELAY_PIN_OUT_3};
int8_t relayIndicatorPin[MAX_RELAY]    = {RELAY_PIN_IND_0, RELAY_PIN_IND_1, RELAY_PIN_IND_2, RELAY_PIN_IND_3};


void setupRelay(){
    for (int8_t i = 0; i < MAX_RELAY; i++) {
        pinMode(relayPin[i], OUTPUT);           // PWM Pins Assigned as Output
        pinMode(relayIndicatorPin[i], OUTPUT);  // PWM Indicator Pins Assigned as Output
    }
     //Serial.println("From setupRelay() ...");
}

void setRelayIndicator(){
    int8_t pinStatus[MAX_RELAY];
    for (int8_t i = 0; i < MAX_RELAY; i++){
        pinStatus[i] = EEPROM.read(relayEepromAddress[i]);
        if(pinStatus[i] == 1){
            digitalWrite(relayIndicatorPin[i], HIGH);
        }
        else{
           digitalWrite(relayIndicatorPin[i], LOW); 
        }
    }
}

int8_t setRelayPin(int8_t pin, int8_t pinSetResetValue){                
    EEPROM.update(relayEepromAddress[pin], pinSetResetValue);
    if(pinSetResetValue == 0){
        relayPinValue[pin] = 0;
        digitalWrite(relayPin[pin], 0);
    }
    return ACK;
}

int8_t setRelayAllPin(int8_t pinSetResetValue){                             
    for (int8_t i = 0; i < MAX_RELAY; i++){
        EEPROM.update(relayEepromAddress[i], pinSetResetValue);
        if(pinSetResetValue == 0){
            relayPinValue[i] = 0;
            digitalWrite(relayPin[i], 0);
        }
    }
    return ACK;
}

int8_t setRelayPinValue(int8_t pin, int8_t value){ 
    int8_t pinStatus = EEPROM.read(relayEepromAddress[pin]);
    if(pinStatus == 1){                 
        relayPinValue[pin] = value;
        digitalWrite(relayPin[pin], relayPinValue[pin]);
        return ACK;
    }
    else{
        return NACK;
    }
}

int8_t setRelayAllPinValue(int8_t value){             // have to rethink about this function logic
    int8_t pinStatus;
    for(int8_t i = 0; i < MAX_RELAY; i++){
        pinStatus = EEPROM.read(relayEepromAddress[i]);
        if(pinStatus == 1){                 
            relayPinValue[i] = value;
            digitalWrite(relayPin[i], relayPinValue[i]);
        }
    }
    return ACK;
}

int8_t getRelayPin(int8_t pin){                                        
    int8_t pinStatus = EEPROM.read(relayEepromAddress[pin]);
     if(pinStatus != 1){
        return NACK;
     }
     else{
        return pinStatus;
     } 
}

int8_t* getRelayAllPin(){                            
    static int8_t pinStatus[MAX_RELAY];
    for (int8_t i = 0; i < MAX_RELAY; i++){
        pinStatus[i] = EEPROM.read(relayEepromAddress[i]);
        if(pinStatus[i] != 1){
            pinStatus[i] = -1;
        }
    } 
    return pinStatus;
}

int8_t getRelayPinValue(int8_t pin){   
    int8_t pinStatus;
    int8_t pinValue;
    pinStatus = EEPROM.read(relayEepromAddress[pin]);
    if(pinStatus == 1){
        pinValue = relayPinValue[pin];
    }
    else{
        pinValue = -1;
    } 
    return pinValue;
}

int8_t* getRelayAllPinValue(){                
    int8_t pinStatus[MAX_RELAY];
    static int8_t pinValue[MAX_RELAY];
    for (int8_t i = 0; i < MAX_RELAY; i++){
        pinStatus[i] = EEPROM.read(relayEepromAddress[i]);
        if(pinStatus[i] == 1){
            pinValue[i] = relayPinValue[i];
        }
        else{
            pinValue[i] = -1;
        }
    } 
    return pinValue;
}

void relayIndicator(int8_t pin, int8_t pinSetResetValue){
    digitalWrite(relayIndicatorPin[pin], pinSetResetValue);
}

void relayIndicator(int8_t pinSetResetValue){
    for (int8_t i = 0; i < MAX_RELAY; i++){
         digitalWrite(relayIndicatorPin[i], pinSetResetValue);
    }
}
