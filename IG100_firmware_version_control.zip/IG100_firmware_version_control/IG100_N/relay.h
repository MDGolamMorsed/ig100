#ifndef IGRELAY_H
#define IGRELAY_H

void    setupRelay();
void    setRelayIndicator();
int8_t  setRelayPin(int8_t pin, int8_t pinSetResetValue);    
int8_t  setRelayAllPin(int8_t pinSetResetValue);                 
int8_t  setRelayPinValue(int8_t pin, int8_t value); 
int8_t  setRelayAllPinValue(int8_t value);        
int8_t  getRelayPin(int8_t pin);                      
int8_t* getRelayAllPin();                     
int8_t  getRelayPinValue(int8_t pin);                 
int8_t* getRelayAllPinValue();  
void    relayIndicator(int8_t pin, int8_t pinSetResetValue);
void    relayIndicator(int8_t pinSetResetValue);

#endif
