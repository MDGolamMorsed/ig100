#ifndef IGDIGITAL_H
#define IGDIGITAL_H

void    setupDigital();
int8_t  setDigitalPin(int8_t pin, int8_t pinSetResetValue);  
int8_t  setDigitalAllPin(int8_t pinSetResetValue);               
int8_t  getDigitalPin(int8_t pin);                               
int8_t* getDigitalAllPin();                       
int8_t  getDigitalPinValue(int8_t pin);       
int8_t* getDigitalAllPinValue();                  
int8_t  getDigitalPinTemperature(int8_t pin);
int8_t  getDigitalPinHumidity(int8_t pin);

#endif
