#include "Arduino.h"
#include "ig.h"

int8_t digitalEepromAddress[MAX_DIGITAL]       = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
int8_t analogEepromAddress[MAX_ANALOG]         = {12, 13, 14, 15}; 
int8_t relayEepromAddress[MAX_RELAY]           = {16, 17, 18, 19}; 
int8_t pwmEepromAddress[MAX_PWM]               = {20, 21, 22, 23}; 
int8_t interruptEepromAddress[MAX_INTERRUPT]   = {24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35}; 


int8_t digitalPin[MAX_DIGITAL]          = {DIGITAL_PIN_IN_0, DIGITAL_PIN_IN_1, DIGITAL_PIN_IN_2, DIGITAL_PIN_IN_3, 
                                           DIGITAL_PIN_IN_4, DIGITAL_PIN_IN_5, DIGITAL_PIN_IN_6, DIGITAL_PIN_IN_7, 
                                           DIGITAL_PIN_IN_8, DIGITAL_PIN_IN_9, DIGITAL_PIN_IN_10, DIGITAL_PIN_IN_11};

int8_t interruptPin[MAX_INTERRUPT]      = {0, 0 , 0, 0, INT_PIN_IN_0, INT_PIN_IN_1, 0, 0, 0, 0, INT_PIN_IN_2, INT_PIN_IN_3};
