#include "Arduino.h"
#include "ig.h"
#include "ig_gv.h"
#include "send.h"
#include "interrupt.h"


//int8_t digitalPin[MAX_DIGITAL]         = {DIGITAL_PIN_IN_0, DIGITAL_PIN_IN_1, DIGITAL_PIN_IN_2, DIGITAL_PIN_IN_3,  
//                                          DIGITAL_PIN_IN_4, DIGITAL_PIN_IN_5, DIGITAL_PIN_IN_6, DIGITAL_PIN_IN_7, 
//                                          DIGITAL_PIN_IN_8, DIGITAL_PIN_IN_9, DIGITAL_PIN_IN_10, DIGITAL_PIN_IN_11};
//                                          
//int8_t interruptPin[MAX_INTERRUPT]     = {0, 0 , 0, 0, INT_PIN_IN_1, INT_PIN_IN_2, 0, 0, 0, 0, INT_PIN_IN_3, INT_PIN_IN_4};

//int8_t* replyInterruptPin;

void setupInterrupt(){
    //Serial.println("Calling setupInterrupt() ...");
    for (int8_t i = 0; i < MAX_INTERRUPT; i++){
        if((digitalPin[i] == interruptPin[i])){
            int8_t pinStatus = EEPROM.read(interruptEepromAddress[i]);
            if(pinStatus == 1){
                if(interruptPin[i] == INT_PIN_IN_0){
                    pinMode(interruptPin[i], INPUT);
                    attachInterrupt(digitalPinToInterrupt(interruptPin[i]), buttun_pressed_0, RISING);
                }
                else if(interruptPin[i] == INT_PIN_IN_1){
                    pinMode(interruptPin[i], INPUT);
                    attachInterrupt(digitalPinToInterrupt(interruptPin[i]), buttun_pressed_1, RISING);
                }
                else if(interruptPin[i] == INT_PIN_IN_2){
                    pinMode(interruptPin[i], INPUT);
                    attachInterrupt(digitalPinToInterrupt(interruptPin[i]), buttun_pressed_2, RISING);
                }
                else{
                    pinMode(interruptPin[i], INPUT);
                    attachInterrupt(digitalPinToInterrupt(interruptPin[i]), buttun_pressed_3, RISING);
                }
            }
            else{
                pinMode(interruptPin[i], INPUT);
                detachInterrupt(digitalPinToInterrupt(interruptPin[i]));
            }
        }
        else{
            // do nothing
        }
    }
    return ACK;
}

int8_t setInterruptPin(int8_t pin, int8_t pinSetResetValue){
    //Serial.println("Calling setInterruptPin() ...");
    if((digitalPin[pin] == interruptPin[pin])){
        int8_t pinStatus = EEPROM.read(digitalEepromAddress[pin]);
        //Serial.println(pinStatus);
        if(pinStatus == 1){
            return NACK;
        }
        else{
            if(pinSetResetValue == 1){
                EEPROM.update(interruptEepromAddress[pin], pinSetResetValue);
                if(interruptPin[pin] == INT_PIN_IN_0){
                    pinMode(interruptPin[pin], INPUT);
                    attachInterrupt(digitalPinToInterrupt(interruptPin[pin]), buttun_pressed_0, RISING);
                }
                else if(interruptPin[pin] == INT_PIN_IN_1){
                    pinMode(interruptPin[pin], INPUT);
                    attachInterrupt(digitalPinToInterrupt(interruptPin[pin]), buttun_pressed_1, RISING);
                }
                else if(interruptPin[pin] == INT_PIN_IN_2){
                    pinMode(interruptPin[pin], INPUT);
                    attachInterrupt(digitalPinToInterrupt(interruptPin[pin]), buttun_pressed_2, RISING);
                }
                else{
                    pinMode(interruptPin[pin], INPUT);
                    attachInterrupt(digitalPinToInterrupt(interruptPin[pin]), buttun_pressed_3, RISING);
                }
                return ACK;
            }
            else{
                EEPROM.update(interruptEepromAddress[pin], pinSetResetValue);
                pinMode(interruptPin[pin], INPUT);
                detachInterrupt(digitalPinToInterrupt(interruptPin[pin]));
                return ACK;
            }
        }
    }
    else{
        return NACK;
    }
}

//-------------------------------------------------------------
void buttun_pressed_0(){
    //Serial.println("interrupt 0");
    sendValue('i', 0);
//    replyInterruptPin[0] = 'i';
//    replyInterruptPin[1] = 0;
//    //replyInterruptPin[1] = '0';
//    sendValue(2, replyInterruptPin);
}
void buttun_pressed_1(){
    //Serial.println("interrupt 1");
    sendValue('i', 1);
//    replyInterruptPin[0] = 'i';
//    replyInterruptPin[1] = 1;
//    //replyInterruptPin[1] = '1';
//    sendValue(2, replyInterruptPin);
}
void buttun_pressed_2(){
    //Serial.println("interrupt 2");
    sendValue('i', 2);
//    replyInterruptPin[0] = 'i';
//    replyInterruptPin[1] = 2;
//    //replyInterruptPin[1] = '2';
//    sendValue(2, replyInterruptPin);
}
void buttun_pressed_3(){
    //Serial.println("interrupt 3");
    sendValue('i', 3);
//    replyInterruptPin[0] = 'i';
//    replyInterruptPin[1] = 3;
//    //replyInterruptPin[1] = '3';
//    sendValue(2, replyInterruptPin);
}
//-------------------------------------------------------------

int8_t setInterruptAllPin(int8_t pinSetResetValue){
    //Serial.println("Calling setInterruptAllPin() ...");
    for (int8_t i = 0; i < MAX_INTERRUPT; i++){
        if((digitalPin[i] == interruptPin[i])){
            EEPROM.update(digitalEepromAddress[i], 0);
            EEPROM.update(interruptEepromAddress[i], pinSetResetValue);
            if(pinSetResetValue == 1){
                if(interruptPin[i] == INT_PIN_IN_0){
                    pinMode(interruptPin[i], INPUT);
                    attachInterrupt(digitalPinToInterrupt(interruptPin[i]), buttun_pressed_0, RISING);
                }
                else if(interruptPin[i] == INT_PIN_IN_1){
                    pinMode(interruptPin[i], INPUT);
                    attachInterrupt(digitalPinToInterrupt(interruptPin[i]), buttun_pressed_1, RISING);
                }
                else if(interruptPin[i] == INT_PIN_IN_2){
                    pinMode(interruptPin[i], INPUT);
                    attachInterrupt(digitalPinToInterrupt(interruptPin[i]), buttun_pressed_2, RISING);
                }
                else{
                    pinMode(interruptPin[i], INPUT);
                    attachInterrupt(digitalPinToInterrupt(interruptPin[i]), buttun_pressed_3, RISING);
                }
            }
            else{
                pinMode(interruptPin[i], INPUT);
                detachInterrupt(digitalPinToInterrupt(interruptPin[i]));
            }
        }
        else{
            // do nothing
        }
    }
    return ACK;
}

int8_t getInterruptPin(int8_t pin){
    //Serial.println("Calling getInterruptPin() ...");
    if((digitalPin[pin] == interruptPin[pin])){
        int8_t pinStatus = EEPROM.read(interruptEepromAddress[pin]);
        if(pinStatus != 1){
            return NACK;
        }
        else{
            return pinStatus;
        }
    }
    else{
        return OUT_OF_RANGE;
    }
}

int8_t* getInterruptAllPin(){
    //Serial.println("Calling getInterruptAllPin() ...");
    static int8_t pinStatus[MAX_INTERRUPT];
    for (int8_t i = 0; i < MAX_INTERRUPT; i++) {
        if((digitalPin[i] == interruptPin[i])){
            pinStatus[i] = EEPROM.read(interruptEepromAddress[i]);
            if(pinStatus[i] == 1){
                //pinStatus[i] = 1;
                // don nothing
            }
            else{
                pinStatus[i] = -1;
            }
        }
        else{
            pinStatus[i] = 0;
        }
        
    }
    return pinStatus;
}
