#include "Arduino.h"
#include "ig.h"
#include "ig_gv.h"
#include "pwm.h"

int8_t pwmPinValue[MAX_PWM]     = {0, 0, 0, 0};
int8_t pwmPin[MAX_PWM]          = {PWM_PIN_OUT_0, PWM_PIN_OUT_1, PWM_PIN_OUT_2, PWM_PIN_OUT_3};
int8_t pwmIndicatorPin[MAX_PWM] = {PWM_PIN_IND_0, PWM_PIN_IND_1, PWM_PIN_IND_2, PWM_PIN_IND_3};

void setupPwm(){
    for (int8_t i = 0; i < MAX_PWM; i++) {
        pinMode(pwmPin[i], OUTPUT);           // PWM Pins Assigned as Output
        pinMode(pwmIndicatorPin[i], OUTPUT);  // PWM Indicator Pins Assigned as Output
    }
     //Serial.println("From setupPwm() ...");
}

void setPwmIndicator(){
    int8_t pinStatus[MAX_PWM];
    for (int8_t i = 0; i < MAX_PWM; i++){
        pinStatus[i] = EEPROM.read(pwmEepromAddress[i]);
        if(pinStatus[i] == 1){
            digitalWrite(pwmIndicatorPin[i], HIGH);
        }
        else{
           digitalWrite(pwmIndicatorPin[i], LOW); 
        }
    }
}

int8_t setPwmPin(int8_t pin, int8_t pinSetResetValue){                
    EEPROM.update(pwmEepromAddress[pin], pinSetResetValue);
    if(pinSetResetValue == 0){
        pwmPinValue[pin] = 0;           
        analogWrite(pwmPin[pin], 0);
    }
    return ACK;
}

int8_t setPwmAllPin(int8_t pinSetResetValue){                               
    for (int8_t i = 0; i < MAX_PWM; i++){
        EEPROM.update(pwmEepromAddress[i], pinSetResetValue);
        if(pinSetResetValue == 0){
            pwmPinValue[i] = 0;
            analogWrite(pwmPin[i], 0);
        }
    }
    return ACK;
}

int8_t setPwmPinValue(int8_t pin, int8_t value){
    int8_t pinStatus = EEPROM.read(pwmEepromAddress[pin]);
    if(pinStatus == 1){                    
        pwmPinValue[pin] = value;
        analogWrite(pwmPin[pin], map(pwmPinValue[pin], 0, 100, 0, 255));
        return ACK;
    }
    else{
        return NACK;
    }
}

int8_t setPwmAllPinValue(int8_t value){                   // have to rethink about the logic of this function
    int8_t pinStatus;
    for(int8_t i = 0; i < MAX_PWM; i++){
        pinStatus = EEPROM.read(pwmEepromAddress[i]);
        if(pinStatus == 1){                    
            pwmPinValue[i] = value;
            analogWrite(pwmPin[i], map(pwmPinValue[i], 0, 100, 0, 255));
        }
    }
    return ACK;
}

int8_t getPwmPin(int8_t pin){                                
    int8_t pinStatus = EEPROM.read(pwmEepromAddress[pin]);
     if(pinStatus != 1){
        return NACK;
     }
     else{
        return pinStatus;
     } 
}

int8_t* getPwmAllPin(){                           
    static int8_t pinStatus[MAX_PWM];
    for (int8_t i = 0; i < MAX_PWM; i++){
        pinStatus[i] = EEPROM.read(pwmEepromAddress[i]);
        if(pinStatus[i] != 1){
            pinStatus[i] = -1;
        }
    } 
    return pinStatus;     
}

int8_t getPwmPinValue(int8_t pin){                           
    int8_t pinStatus;
    int8_t pinValue;
    pinStatus = EEPROM.read(pwmEepromAddress[pin]);
    if(pinStatus == 1){
        pinValue = pwmPinValue[pin];
    }
    else{
        pinValue = -1;
    } 
    return pinValue;
}

int8_t* getPwmAllPinValue(){                  
    int8_t pinStatus[MAX_PWM];
    static int8_t pinValue[MAX_PWM];
    for (int8_t i = 0; i < MAX_PWM; i++){
        pinStatus[i] = EEPROM.read(pwmEepromAddress[i]);
        if(pinStatus[i] == 1){
            pinValue[i] = pwmPinValue[i];
        }
        else{
            pinValue[i] = -1;
        }
    } 
    return pinValue;
}

void pwmIndicator(int8_t pin, int8_t pinSetResetValue){
    digitalWrite(pwmIndicatorPin[pin], pinSetResetValue);
}

void pwmIndicator(int8_t pinSetResetValue){
    for (int8_t i = 0; i < MAX_PWM; i++){
         digitalWrite(pwmIndicatorPin[i], pinSetResetValue);
    }
}
