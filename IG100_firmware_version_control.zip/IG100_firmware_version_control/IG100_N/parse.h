#ifndef IGPARSE_H
#define IGPARSE_H

void parseCmd();

#endif
