#include "Arduino.h"
#include "send.h"

//
//void sendValue(int8_t value){
//        Serial.write(value);
//        Serial.write('\t');
//}
//
//
//void sendValue(int8_t array_length, int8_t* value){     // have to think more here
//    for(int8_t i = 0; i < array_length; i++){
//        Serial.write(value[i]);       
//    }
//    Serial.write('\t');
//}
//
//void sendValue(char interrupt, int8_t value){
//    Serial.write(interrupt);
//    Serial.write(value);
//    Serial.write('\t');
//}



void sendValue(int8_t value){
        Serial.print(value);
        Serial.print('\n');
}

void sendValue(int8_t array_length, int8_t* value){
    for(int8_t i = 0; i < array_length - 1; i++){
        Serial.print(value[i]);
        Serial.print(",");       
    }
    Serial.print(value[array_length - 1]);
    Serial.print('\n');
}

void sendValue(char interrupt, int8_t value){
    Serial.write(interrupt);
    Serial.write(value);
    Serial.write('\n');
}
