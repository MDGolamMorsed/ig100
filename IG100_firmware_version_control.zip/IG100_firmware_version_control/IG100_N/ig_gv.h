#ifndef IGGLOB_H
#define IGGLOB_H

#include <EEPROM.h>
#include <avr/wdt.h> 
#include <dht.h>    

extern int8_t digitalEepromAddress[MAX_DIGITAL];
extern int8_t analogEepromAddress[MAX_ANALOG];
extern int8_t relayEepromAddress[MAX_RELAY];
extern int8_t pwmEepromAddress[MAX_PWM];
extern int8_t interruptEepromAddress[MAX_INTERRUPT];


extern int8_t digitalPin[MAX_DIGITAL];
extern int8_t interruptPin[MAX_INTERRUPT];

#endif
