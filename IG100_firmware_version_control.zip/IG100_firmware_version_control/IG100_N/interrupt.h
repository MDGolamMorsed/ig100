#ifndef IGINTERRUPT_H
#define IGINTERRUPT_H

void    setupInterrupt();
int8_t  setInterruptPin(int8_t pin, int8_t pinSetResetValue);
int8_t  setInterruptAllPin(int8_t pinSetResetValue);
int8_t  getInterruptPin(int8_t pin);
int8_t* getInterruptAllPin();

void buttun_pressed_0();
void buttun_pressed_1();
void buttun_pressed_2();
void buttun_pressed_3();

#endif
