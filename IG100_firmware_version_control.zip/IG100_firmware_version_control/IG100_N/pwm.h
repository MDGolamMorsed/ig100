#ifndef IGPWM_H
#define IGPWM_H

void    setupPwm();
void    setPwmIndicator();
int8_t  setPwmPin(int8_t pin, int8_t pinSetResetValue);      
int8_t  setPwmAllPin(int8_t pinSetResetValue);                   
int8_t  setPwmPinValue(int8_t pin, int8_t value);
int8_t  setPwmAllPinValue(int8_t value);                 
int8_t  getPwmPin(int8_t pin);                    
int8_t* getPwmAllPin();                               
int8_t  getPwmPinValue(int8_t pin);               
int8_t* getPwmAllPinValue();
void    pwmIndicator(int8_t pin, int8_t pinSetResetValue);
void    pwmIndicator(int8_t pinSetResetValue);

#endif
