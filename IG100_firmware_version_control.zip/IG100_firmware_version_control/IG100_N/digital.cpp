#include "Arduino.h"
#include "ig.h"
#include "ig_gv.h"
#include "digital.h"

dht DHT;


//int8_t digitalPin[MAX_DIGITAL]         = {DIGITAL_PIN_IN_0, DIGITAL_PIN_IN_1, DIGITAL_PIN_IN_2, DIGITAL_PIN_IN_3,  
//                                          DIGITAL_PIN_IN_4, DIGITAL_PIN_IN_5, DIGITAL_PIN_IN_6, DIGITAL_PIN_IN_7, 
//                                          DIGITAL_PIN_IN_8, DIGITAL_PIN_IN_9, DIGITAL_PIN_IN_10, DIGITAL_PIN_IN_11};
//                                          
//int8_t interruptPin[MAX_INTERRUPT]     = {0, 0 , 0, 0, INT_PIN_IN_1, INT_PIN_IN_2, 0, 0, 0, 0, INT_PIN_IN_3, INT_PIN_IN_4};


void setupDigital(){
    for (int8_t i = 0; i < MAX_DIGITAL; i++) {
        pinMode(digitalPin[i], INPUT);           // Digital Pins Assigned as intput
    }
     //Serial.println("From setupDigital() ...");
}

int8_t setDigitalPin(int8_t pin, int8_t pinSetResetValue){              
//    EEPROM.update(digitalEepromAddress[pin], pinSetResetValue);
//    return ACK;
    if((digitalPin[pin] == interruptPin[pin])){
        int8_t pinStatus = EEPROM.read(interruptEepromAddress[pin]);  // THINK HERE
        //Serial.println(pinStatus);
        if(pinStatus == 1){
            return NACK;
        }
        else{
            EEPROM.update(digitalEepromAddress[pin], pinSetResetValue);
            return ACK;
        }
    }
    else{
        EEPROM.update(digitalEepromAddress[pin], pinSetResetValue);
        return ACK;
    }
}

int8_t setDigitalAllPin(int8_t pinSetResetValue){                           
    for (int8_t i = 0; i < MAX_DIGITAL; i++){
        if((digitalPin[i] == interruptPin[i])){
            EEPROM.update(interruptEepromAddress[i], 0);
            EEPROM.update(digitalEepromAddress[i], pinSetResetValue);
        }
        else{
            EEPROM.update(digitalEepromAddress[i], pinSetResetValue);
        }
    }
    return ACK;
}

int8_t getDigitalPin(int8_t pin){                
    int8_t pinStatus = EEPROM.read(digitalEepromAddress[pin]);
     if(pinStatus != 1){
        return NACK;
     }
     else{
        return pinStatus;
     }
}

int8_t* getDigitalAllPin(){                                       
    static int8_t pinStatus[MAX_DIGITAL];
    for (int8_t i = 0; i < MAX_DIGITAL; i++) {
        pinStatus[i] = EEPROM.read(digitalEepromAddress[i]);
        if(pinStatus[i] != 1){
            pinStatus[i] = -1;
        }
    }
    return pinStatus;
}

int8_t getDigitalPinValue(int8_t pin){           
    int8_t pinStatus = EEPROM.read(digitalEepromAddress[pin]);
    if(pinStatus == 1){
        int8_t pinValue = digitalRead(digitalPin[pin]);
        return pinValue;
    }
    else{
        return -1;         
    }
}

int8_t* getDigitalAllPinValue(){                    
    int8_t pinStatus ;
    static int8_t pinValue[MAX_DIGITAL];         
    for (int8_t i = 0; i < MAX_DIGITAL; i++) {
        pinStatus = EEPROM.read(digitalEepromAddress[i]);
        if(pinStatus == 1){
            pinValue[i] = digitalRead(digitalPin[i]);
        }
        else {
            pinValue[i] = -1;
        }
    }
    return pinValue;
}

int8_t getDigitalPinTemperature(int8_t pin){
    int8_t dhtTemp = 0;
    int8_t pinStatus = EEPROM.read(digitalEepromAddress[pin]);
    if(pinStatus == 1){
        int8_t chk = DHT.read11(digitalPin[pin]);  // will configure with rafsan
        dhtTemp = DHT.temperature;
        //delay(1000);                                // will configure with rafsan
        return dhtTemp;
    }
    else{
        return NACK;
    }
}

int8_t getDigitalPinHumidity(int8_t pin){
    int8_t dhtHum = 0;
    int8_t pinStatus = EEPROM.read(digitalEepromAddress[pin]);
    if(pinStatus == 1){
        DHT.read11(digitalPin[pin]);
        dhtHum = DHT.humidity;
        return dhtHum;
    }
    else{
        return NACK;
    }
}
