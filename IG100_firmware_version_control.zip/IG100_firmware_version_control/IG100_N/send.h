#ifndef IGSEND_H
#define IGSEND_H

void sendValue(int8_t value);
void sendValue(int8_t array_length, int8_t* value);
void sendValue(char interrupt, int8_t value);

#endif
