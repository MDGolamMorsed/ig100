function _(id) { return document.getElementById(id); }
(function () {
    var c_output = _("choose-output"),
        c_action = _("choose-action"),
        c_notify = _("choose-notification");

    c_action.addEventListener('change', function (event) {
        var val = this.value;
        if (val === "notification") {
            c_notify.style.display = 'block';
            c_output.style.display = 'none';
        } else {
            c_notify.style.display = 'none';
            c_output.style.display = 'block';
        }
    });

    var state = intialState = {
        isAdded: false,
        inputs: [],
        condition: [],
        condition_value: [],
        join_by: [],
        outputs: [],
    },
        cond_choose_input = _("choose-input"),
        cond_choose_cond = _("choose-condition"),
        cond_comp_value = _("compare-valuee"),
        cond_add_btn = _("add_cond"),
        cond_and_btn = _("and_join"),
        cond_or_btn = _("or_join"),
        out_choose_output = _("choose-output"),
        out_value = _("set-value"),
        add_output_btn = _("add_output"),
        main_conditions_hidden = _("conditions");

    function attachToForm() {
        console.log(state);
        main_conditions_hidden.value = JSON.stringify(state);
    }

    function representaionalUI(value, className, type){
        type = type || 'p';
        var definitionElm = document.createElement(type);
            definitionElm.classList.add(className);
            definitionElm.innerHTML = value;
        return definitionElm;
    }

    function generateInputComponent(index, definition, condition, value, join_by){
        var conditionMap = {
            less_than: 'Less Than',
            greater_than: 'Greater Than',
            greater_or_equal: 'Greater Than or Equal To',
            less_or_equal: 'Less Than or Equal To',
            equal: 'Equal To'
        }
        var singleCondition = document.createElement("div");
            singleCondition.classList.add("single_condition");

        var button = document.createElement('button');
            button.classList.add('close_button');
            button.type = 'button';
            button.innerHTML = 'X';
            button.addEventListener('click', function () {
                var c = confirm("Do you want to remove it ?");
                if(c){
                    state.condition.splice(index, 1);
                    state.condition_value.splice(index, 1);
                    state.join_by.splice(index, 1);
                    state.inputs.splice(index, 1);
                    state.isAdded = false;
                    updateInputList();
                }
            });
            singleCondition.appendChild(button);

        singleCondition.appendChild(representaionalUI(definition, 'defination'));
        var condVale = conditionMap[condition] + ": <strong>" + value + "</strong>";
        singleCondition.appendChild(representaionalUI(condVale, 'condition'));
        

        if(join_by && join_by !== ''){
            singleCondition.appendChild(representaionalUI(join_by, 'joinby', 'div'));
        }

        return singleCondition;
    }
    function updateInputList() {
        attachToForm();
        var inputsList = _("all_added_condition");
        inputsList.innerHTML = "";
        var width = 470, 
            isHasError = false;
        for (var i = 0; i < state.inputs.length; i++) {
            var configuration = inputs_map[state.inputs[i]].configuration;
            if(configuration && configuration.defination){
                var definition = inputs_map[state.inputs[i]].configuration.defination; 
                var condition = state.condition[i];
                var value =  state.condition_value[i];
                var join_by = state.join_by[i] ? state.join_by[i] : '';
                inputsList.appendChild(generateInputComponent(i, definition, condition, value, join_by));
                if(i > 0){
                    width = width + 220;
                }
            } else {
                isHasError = true;
            }
        }
        _("all_condtion_container").style.width = width + 'px';
        if(isHasError){
            alert("There are some error, please make sure all configured input exists.");
        }
    }

    function setStyle(element, styleObj) {
        for (var prop in styleObj) {
            element.style[prop] = styleObj[prop];
        }
    }

    function createSingleOutputElement(index, title, descriptoin, type, interval, value, pin) {
        var singleOutput = document.createElement("div");
        singleOutput.classList.add('single_output');

        var button = document.createElement('button');
        button.classList.add('close_button');
        button.type = 'button';
        button.innerHTML = 'X';
        button.addEventListener('click', function () {
            var c = confirm("Do you want to remove it ?");
            if(c){
                state.outputs.splice(index, 1);
                updateOutputList();
            }
        });
        singleOutput.appendChild(button);

        var titleElm = document.createElement('p');
        titleElm.innerHTML = title;
        singleOutput.appendChild(titleElm);

        if (descriptoin) {
            var descriptoinElm = document.createElement('p');
            descriptoinElm.innerHTML = descriptoin;
            singleOutput.appendChild(descriptoinElm);
        }

        var typeElm = document.createElement('p');
        typeElm.innerHTML = 'Type: <strong>' + type + '</strong>';
        singleOutput.appendChild(typeElm);

        if (interval) {
            var intervalElm = document.createElement('p');
            intervalElm.innerHTML = 'Interval: <strong>'+interval+'</strong>';
            singleOutput.appendChild(intervalElm);
        }
        if (value) {
            var valueElm = document.createElement('p');
            valueElm.innerHTML = 'Set Value: <strong>'+value+'</strong>';
            singleOutput.appendChild(valueElm);
        }
        if (pin) {
            var pinElm = document.createElement('p');
            pinElm.innerHTML = 'Output Port: <strong>'+pin+'</strong>';
            singleOutput.appendChild(pinElm);
        }

        return singleOutput;
    }
    
    function updateOutputList() {
        attachToForm();
        var outputs_container = _("ouputs_list_container");
        outputs_container.innerHTML = "";
        for (var i = 0; i < state.outputs.length; i++) {
            var uid = state.outputs[i].uid;
            if (!(outputs_map[uid] || notification_map[uid])) {
                state.outputs.splice(i, 1);
                continue;
            }
            var title = null, 
                description = null, 
                interval = null,
                value = null,
                pin = null;
            title = outputs_map[uid] ?
                outputs_map[uid].configuration.defination :
                notification_map[uid].name;
            var type = state.outputs[i].type;
            if(notification_map[uid]){
                interval = notification_map[uid].interval;
            }
            if(notification_map[uid]){
                description = notification_map[uid].text;
            }
            if(outputs_map[uid]){
                value = state.outputs[i].set_value;
                pin = outputs_map[uid].port;
            }
            var element = createSingleOutputElement(i, title, description, type, interval, value, pin);
            outputs_container.appendChild(element);
        }
    }
    function resetInput() {
        cond_choose_input.value = "-1";
        cond_choose_cond.value = "-1";
        cond_comp_value.value = "";
    }

    function inputsError() {
        if (cond_choose_input.value == "" || cond_choose_input.value.length < 1 || cond_choose_input.value === "-1") {
            return "plese select valid input";
        }
        if (cond_choose_cond.value === "" || cond_choose_cond.value.length < 1 || cond_choose_cond.value === "-1") {
            return "Please select valid condition";
        }
        if (cond_comp_value.value.length < 1 || parseInt(cond_comp_value.value) === NaN) {
            return "Please enter valid compare value";
        }
        return null;
    }
    function addInput(type) {
        var inputError = inputsError();
        console.log(inputError);
        if (state.isAdded) {
            alert("You can't add more condition after completion one.");
        } else if (inputError !== null) {
            alert(inputError);
        } else {
            var input = cond_choose_input.value,
                cond = cond_choose_cond.value,
                comp_value = cond_comp_value.value;
            if (type === 'and' || type === 'or') {
                if (type === 'and') {
                    state.join_by.push('and');
                } else {
                    state.join_by.push('or');
                }
            } else {
                state.isAdded = true;
            }
            state.inputs.push(input);
            state.condition.push(cond);
            state.condition_value.push(comp_value);
            updateInputList();
            resetInput();
        }
    }
    cond_add_btn.addEventListener("click", addInput);
    cond_and_btn.addEventListener("click", function () { addInput('and') });
    cond_or_btn.addEventListener("click", function () { addInput('or') });


    add_output_btn.addEventListener("click", function () {
        var output = out_choose_output.value,
            value = out_value.value;
        var _output_obj = {}
        if (c_action.value === "notification") {
            _output_obj = {
                type: 'notification',
                set_value: value,
                uid: c_notify.value,
            }
            c_notify.value = "-1";
        } else {
            _output_obj = {
                type: 'output',
                set_value: value,
                uid: output,
            }
            out_choose_output.value = "-1";
        }
        state.outputs.push(_output_obj);
        out_value.value = "";
        updateOutputList();
    });


    window.addEventListener("click", function (event) {
        var output_delete_btn = "data-output-delete";
        var input_reset = 'data-input-reset';
        var target = event.target;
        if (target) {
            var attr = target.getAttribute(output_delete_btn);
            if (attr) {
                attr = parseInt(attr);
                if (confirm("Are you sure ??")) {
                    state.outputs.splice(attr, 1);
                    updateOutputList();
                }
            } else {
                attr = target.getAttribute(input_reset);
                console.log("input attr", attr);
                if (attr === 'all') {
                    if (confirm("Are you sure ??")) {
                        state.isAdded = false;
                        state.inputs = [];
                        state.condition = [];
                        state.condition_value = [];
                        state.join_by = [];
                        updateInputList();
                    }
                }
            }
        }
    });

    var trigger_remove_btns = document.querySelectorAll("button[data-trigger-remove-btn]");
    var trigger_update_btns = document.querySelectorAll("button[data-trigger-update]");
    for (var i = 0; i < trigger_remove_btns.length; i++) {
        trigger_remove_btns[i].addEventListener("click", function (event) {
            event.preventDefault();
            event.stopPropagation();
            if (confirm("Are you sure ?")) {
                var form = this.parentElement || this.form;
                form.submit();
            }
        });
    }

    for (var i = 0; i < trigger_update_btns.length; i++) {
        trigger_update_btns[i].addEventListener("click", function (event) {
            event.preventDefault();
            var key = this.getAttribute('data-trigger-update');
            updateTrigger(key);
        });
    }

    function updateTrigger(key) {
        var trigger = triggers_map[key];
        _("trigger_uid").value = key;
        _("trigger-name").value = trigger.trigger_name;
        _("trigger-time").value = trigger.triggertime;
        _("trigger-description").value = trigger.definition;

        _("create_trigger_btn").innerHTML = "Update Trigger";
        state = { ...trigger, isAdded: false };
        updateInputList();
        updateOutputList();

    }

    _("create_trigger_btn").addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        if (_("trigger-name").value.length < 1) {
            alert("Please enter a trigger name");
        } else if (_("trigger-description").value.length < 1) {
            alert("Please enter trigger description");
        } else if (_("trigger-time").value.length < 1) {
            alert("Please enter trigger time");
        } else if (state.inputs.length < 1) {
            alert("Please Add Some condition");
        } else {
            _("create_trigger_form").submit();
        }
    });

    _("trigger_cancel_btn").addEventListener("click", function (event) {
        _("trigger_uid").value = "";
        _("trigger-name").value = "";
        _("trigger-time").value = "";
        _("trigger-description").value = "";
        state = intialState;
        updateInputList();
        updateOutputList();
        _("create_trigger_btn").innerHTML = "Create Trigger";
    });
}());

